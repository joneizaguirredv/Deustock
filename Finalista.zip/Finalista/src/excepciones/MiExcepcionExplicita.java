package excepciones;

public class MiExcepcionExplicita extends Exception {
	private String mensaje;

	public MiExcepcionExplicita(String m) {
		mensaje = m;
	}

	public String toString() {
		return mensaje;
	}

}
