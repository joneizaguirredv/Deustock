package clases;

import enumeraciones.MarcasProductos;
import enumeraciones.TipoZapatilla;

public class AtuendoZapatilla extends Producto {
	private String Talla;
	private String ColorCordon;
	private TipoZapatilla Tipo;

	public AtuendoZapatilla(int id, String nombre, int precio, MarcasProductos marca, String genero, int peso, String color, String material,
			Boolean estampado, int cantidad, String talla, String colorCordon, TipoZapatilla tipo) {
		super(id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad);
		Talla = talla;
		ColorCordon = colorCordon;
		Tipo = tipo;
	}

	public String getTalla() {
		return Talla;
	}

	public void setTalla(String talla) {
		Talla = talla;
	}

	public String getColorCordon() {
		return ColorCordon;
	}

	public void setColorCordon(String colorCordon) {
		ColorCordon = colorCordon;
	}

	public TipoZapatilla getTipo() {
		return Tipo;
	}

	public void setTipo(TipoZapatilla tipo) {
		Tipo = tipo;
	}

	@Override
	public String toString() {
		return "AtuendoZapatilla [Talla=" + Talla + ", ColorCordon=" + ColorCordon + ", Tipo=" + Tipo + ", toString()="
				+ super.toString() + "]";
	}

}