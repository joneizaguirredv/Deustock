package clases;

import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;
import enumeraciones.TipoPantalon;

public class AtuendosParteAbajo extends Producto {
	private TipoPantalon Tipo;
	private TallaParteArribaYAbajo Talla;

	public AtuendosParteAbajo(int id, String nombre, int precio, MarcasProductos marca, String genero, int peso, String color, String material,
			Boolean estampado, int cantidad, TipoPantalon tipo, TallaParteArribaYAbajo talla) {
		super(id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad);
		Tipo = tipo;
		Talla = talla;
	}

	public TipoPantalon getTipo() {
		return Tipo;
	}

	public void setTipo(TipoPantalon tipo) {
		Tipo = tipo;
	}

	public TallaParteArribaYAbajo getTalla() {
		return Talla;
	}

	public void setTalla(TallaParteArribaYAbajo talla) {
		Talla = talla;
	}

	@Override
	public String toString() {
		return "AtuendosParteAbajo [Tipo=" + Tipo + ", Talla=" + Talla + ", toString()=" + super.toString() + "]";
	}

}
