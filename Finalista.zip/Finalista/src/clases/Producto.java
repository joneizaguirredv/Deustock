package clases;

import enumeraciones.MarcasProductos;

public class Producto {
	private int Id;
	private String Nombre;
	private int Precio;
	private MarcasProductos Marca;
	private String Genero;
	private int Peso;
	private String Color;
	private String Material;
	private Boolean Estampado;
	private int Cantidad;
	
	
	public Producto(int id, String nombre, int precio, MarcasProductos marca, String genero, int peso, String color,
			String material, Boolean estampado, int cantidad) {
		super();
		Id = id;
		Nombre = nombre;
		Precio = precio;
		Marca = marca;
		Genero = genero;
		Peso = peso;
		Color = color;
		Material = material;
		Estampado = estampado;
		Cantidad = cantidad;
	}


	public int getId() {
		return Id;
	}


	public void setId(int id) {
		Id = id;
	}


	public String getNombre() {
		return Nombre;
	}


	public void setNombre(String nombre) {
		Nombre = nombre;
	}


	public int getPrecio() {
		return Precio;
	}


	public void setPrecio(int precio) {
		Precio = precio;
	}


	public MarcasProductos getMarca() {
		return Marca;
	}


	public void setMarca(MarcasProductos marca) {
		Marca = marca;
	}


	public String getGenero() {
		return Genero;
	}


	public void setGenero(String genero) {
		Genero = genero;
	}


	public int getPeso() {
		return Peso;
	}


	public void setPeso(int peso) {
		Peso = peso;
	}


	public String getColor() {
		return Color;
	}


	public void setColor(String color) {
		Color = color;
	}


	public String getMaterial() {
		return Material;
	}


	public void setMaterial(String material) {
		Material = material;
	}


	public Boolean getEstampado() {
		return Estampado;
	}


	public void setEstampado(Boolean estampado) {
		Estampado = estampado;
	}


	public int getCantidad() {
		return Cantidad;
	}


	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}


	@Override
	public String toString() {
		return "Producto [Id=" + Id + ", Nombre=" + Nombre + ", Precio=" + Precio + ", Marca=" + Marca + ", Genero="
				+ Genero + ", Peso=" + Peso + ", Color=" + Color + ", Material=" + Material + ", Estampado=" + Estampado
				+ ", Cantidad=" + Cantidad + "]";
	}
	
	
	

	

}
