package ventanas;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.plaf.DimensionUIResource;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;


import enumeraciones.TallaParteArribaYAbajo;

import BaseDeDatos.BaseDeDatos;
import clases.AtuendoZapatilla;
import clases.AtuendosParteAbajo;
import clases.AtuendosParteArriba;
import clases.Carrito;
import clases.Pago;
import clases.Pedido;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Vector;

public class VentanaUsuario extends JFrame {
	private JLabel logo; // }<-- Panel Superior
	private JPanel superiorLogo;
	private JButton btnInicio;
	private JButton btnHombre;
	private JButton btnMujer;
	private JButton btnCuenta;
	private JPanel superiorVentanas;
	private JButton btnCarrito;
	private JButton btnA�adirACarrito;
	private JLabel totalLbl;
	private JPanel superiorCarrito;
	private JPanel superior;
	private JPanel core; // centro
	private JPanel panelPago;
	private JPanel margenIzq; // }<-- Margen
	private JPanel margenInferior;
	private JButton btnParteArriba;
	private JButton btnParteAbajo;
	private JButton btnCalzado;
	private DefaultTableModel mDatos; // Modelo de datos de tabla central
	private JTable tDatos;
	private int tipo1;
	private JButton realizarCompra;
	private JDateChooser FechaLlegada;
	public VentanaUsuario() {
		this.setTitle("Pago");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setLayout(new BorderLayout());

// Panel Superior

		// Panel Superior Izquierda
		tipo1 = -1;
		logo = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/logo.png"));
			logo.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		logo.setBounds(0, 0, 200, 95);

		superiorLogo = new JPanel();
		superiorLogo.setPreferredSize(new Dimension(169, 96));
		superiorLogo.setBackground(Color.WHITE);
		superiorLogo.setLayout(null);
		superiorLogo.add(logo);
		
	
		// Panel Superior Centro
		// TODO setLayout(new GridBagLayout()); <-- La idea es que los botones se
		// adapten al tama�o

		btnInicio = new JButton("INICIO");
		btnInicio.setBounds(20, 35, 160, 35);
		btnInicio.setFont(new Font("Roboto", Font.BOLD, 25));
		btnInicio.setForeground(new Color(0xa8ccba));
		btnInicio.setBackground(Color.WHITE);
		btnInicio.setBorderPainted(false);

		btnHombre = new JButton("HOMBRE");
		btnHombre.setBounds(230, 35, 160, 35);
		btnHombre.setFont(new Font("Consolas", Font.BOLD, 25));
		btnHombre.setForeground(new Color(0xa8ccba));
		btnHombre.setBackground(Color.WHITE);
		btnHombre.setBorderPainted(false);

		btnMujer = new JButton("MUJER");
		btnMujer.setBounds(440, 35, 160, 35);
		btnMujer.setFont(new Font("Roboto", Font.BOLD, 25));
		btnMujer.setForeground(new Color(0xa8ccba));
		btnMujer.setBackground(Color.WHITE);
		btnMujer.setBorderPainted(false);

		btnCuenta = new JButton();
		try {
			Image img = ImageIO.read(getClass().getResource("/cuenta.png"));
			btnCuenta.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		btnCuenta.setText("CUENTA: ");
		btnCuenta.setIconTextGap(10);
		btnCuenta.setBounds(640, 5, 250, 90);
		btnCuenta.setFont(new Font("Roboto", Font.BOLD, 24));
		btnCuenta.setForeground(new Color(0xa8ccba));
		btnCuenta.setBackground(Color.WHITE);
		btnCuenta.setBorderPainted(false);
		btnCuenta.setHorizontalTextPosition(JButton.LEFT);
		btnCuenta.setVerticalTextPosition(JButton.CENTER);

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0xa2d39b));
		separator.setBounds(0, 95, 2000, 7);

		superiorVentanas = new JPanel();
		superiorVentanas.setBackground(Color.WHITE);
		superiorVentanas.setPreferredSize(new Dimension(0, 0));
		superiorVentanas.setLayout(null);
		superiorVentanas.add(btnInicio);
		superiorVentanas.add(btnHombre);
		superiorVentanas.add(btnMujer);
		superiorVentanas.add(btnCuenta);
		superiorVentanas.add(separator);

		// Panel Superior Derecha

		totalLbl = new JLabel();
		totalLbl.setText("Total:" + getTotalCarrito() + "�");
		//Text label de total metido en el actonlistener de boton a�adir al carrito.
		totalLbl.setForeground(Color.WHITE);
		totalLbl.setFont(new Font("Consolas", Font.BOLD, 20));
		totalLbl.setPreferredSize(new Dimension(150, 50));

		btnCarrito = new JButton();
		try {
			Image img = ImageIO.read(getClass().getResource("/carrito.png"));
			btnCarrito.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		btnCarrito.setPreferredSize(new Dimension(100, 100));
		btnCarrito.setBackground(new Color(0xa8ccba));
		btnCarrito.setForeground(new Color(0xa8ccba));
		btnCarrito.setBorderPainted(false);

		superiorCarrito = new JPanel();
		superiorCarrito.setBackground(new Color(0xa8ccba));
		superiorCarrito.setPreferredSize(new Dimension(250, 0));
		superiorCarrito.setLayout(new BorderLayout());
		superiorCarrito.add(totalLbl, BorderLayout.EAST);
		superiorCarrito.add(btnCarrito, BorderLayout.WEST);

		// Build

		superior = new JPanel();
		superior.setBackground(Color.WHITE);
		superior.setPreferredSize(new Dimension(0, 100));
		superior.setLayout(new BorderLayout());
		superior.add(superiorLogo, BorderLayout.WEST);
		superior.add(superiorVentanas, BorderLayout.CENTER);
		superior.add(superiorCarrito, BorderLayout.EAST);

// Panel Central

		// Panel Inicio
		
		// Panel

		// Panel Pago

		tDatos = new JTable();
		tDatos.setFont(new Font("Arial", Font.PLAIN, 14));

// Margen Izquierdo

		btnParteArriba = new JButton("Atuendo Superior");
		btnParteArriba.setBounds(0, 30, 180, 20);
		btnParteArriba.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnParteArriba.setForeground(new Color(0xffffff));
		btnParteArriba.setBackground(new Color(0xa8ccba));
		btnParteArriba.setBorderPainted(false);

		btnParteAbajo = new JButton("Atuendo Inferior");
		btnParteAbajo.setBounds(10, 65, 175, 20);
		btnParteAbajo.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnParteAbajo.setForeground(new Color(0xffffff));
		btnParteAbajo.setBackground(new Color(0xa8ccba));
		btnParteAbajo.setBorderPainted(false);

		btnCalzado = new JButton("Zapatillas");
		btnCalzado.setBounds(10, 90, 175, 50);
		btnCalzado.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnCalzado.setForeground(new Color(0xffffff));
		btnCalzado.setBackground(new Color(0xa8ccba));
		btnCalzado.setBorderPainted(false);
		btnCalzado.setVisible(true);
		
		btnA�adirACarrito = new JButton("A�adir al carrito");
		btnA�adirACarrito.setBounds(10, 130, 175, 50);
		btnA�adirACarrito.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnA�adirACarrito.setForeground(new Color(0xffffff));
		btnA�adirACarrito.setBackground(new Color(0xa8ccba));
		btnA�adirACarrito.setBorderPainted(false);
		btnA�adirACarrito.setVisible(true);

		margenIzq = new JPanel();
		margenIzq.setBackground(new Color(0xa8ccba));
		margenIzq.setPreferredSize(new Dimension(170, 0));
		margenIzq.setLayout(null);
		margenIzq.add(btnParteArriba);
		margenIzq.add(btnParteAbajo);
		margenIzq.add(btnCalzado);
		margenIzq.add(btnA�adirACarrito);
		
		realizarCompra = new JButton("Realizar compra");
		realizarCompra.setVisible(false);
		realizarCompra.setBounds(50, 1000, 175, 20);
		
		
		FechaLlegada = new JDateChooser();
		FechaLlegada.setVisible(false);
		
		
		
		margenInferior = new JPanel();
		margenInferior.setBackground(new Color(0xa8ccba));
		margenInferior.setLayout(new BorderLayout());
		margenInferior.add(realizarCompra, BorderLayout.CENTER);

		
		core = new JPanel();
		core.setBackground(new Color(0xa8ccba));
		core.setLayout(new BorderLayout());
		core.add(new JScrollPane(tDatos), BorderLayout.CENTER);
		core.add(FechaLlegada, BorderLayout.SOUTH);
		
		this.add(superior, BorderLayout.NORTH);
		this.add(margenIzq, BorderLayout.WEST);
		this.add(margenInferior, BorderLayout.SOUTH);
		this.add(core, BorderLayout.CENTER);

		addWindowListener(new WindowAdapter() {

			public void windowOpened(WindowEvent e) {
				BaseDeDatos.inicioConexion("BaseDeDatos1.db");
			}

			public void windowClosed(WindowEvent e) {
				BaseDeDatos.EliminarUsuarioDeBaseDeDatos();
				BaseDeDatos.cerrarConexion();
			}

		});
		
		
		

		btnParteArriba.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ModeloParteArriba(BaseDeDatos.getAtuendosParteArriba());
				realizarCompra.setVisible(false);
				FechaLlegada.setVisible(false);
				tipo1 = 0;

			}

		});

		btnParteAbajo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ModeloParteAbajo(BaseDeDatos.getAtuendosParteAbajo());
				realizarCompra.setVisible(false);
				FechaLlegada.setVisible(false);
				tipo1 = 1;
			}

		});
		
		
		btnCalzado.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ModeloCalzado(BaseDeDatos.getZapatillas());;
				realizarCompra.setVisible(false);
				FechaLlegada.setVisible(false);
				tipo1 = 2;
				
			}
			
		});
		

		btnA�adirACarrito.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CrearCarrito();
				totalLbl.setText("Total:" + getTotalCarrito() + "�");
				realizarCompra.setVisible(false);
				FechaLlegada.setVisible(false);
				

			}

		});
		
		
		btnCarrito.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				verCarrito();
				realizarCompra.setVisible(true);
				FechaLlegada.setVisible(true);
				
				
			}
			
		});
		
		
		
		
		
		
		realizarCompra.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				//realizarCompra(0);
				
				try {
					PrintWriter pw = new PrintWriter (new FileWriter ("src/BaseDeDatos/Compras.txt", true));
					float costeTotal = calcularCoste(0, 0);
					realizarCompra(0, pw);
					pw.close();
					//JOptionPane.showMessageDialog(null, "Su compra se ha realizado correctamente, y el importe total es de "+costeTotal+" euros");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				ArrayList<String> listaCorreosPagos = BaseDeDatos.getCorreosPagos();
				String correo = BaseDeDatos.cargarCorreoDeUnCliente();
				
				if(listaCorreosPagos.contains(correo)) {
					new VentanaPagoHabitual();
				}else {
					new VentanaPago();
				}
				
				
				
				
			}
			
		});
		
		
		
		btnCuenta.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				verCompras();
				
			}
			
		});
		
		
		
		btnHombre.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String genero = "Hombre";
				
				if(tipo1 == 0) {
					ArrayList<AtuendosParteArriba> lista = BaseDeDatos.getAtuendosParteArribaPorGenero(genero);
					ModeloParteArriba(lista);
					
				}else if(tipo1 == 1) {
					ArrayList<AtuendosParteAbajo> lista = BaseDeDatos.getAtuendosParteAbajoPorGenero(genero);
					ModeloParteAbajo(lista);
					
				}else {
					ArrayList<AtuendoZapatilla> lista = BaseDeDatos.getZapatillasPorGenero(genero);
					ModeloCalzado(lista);
				}
				
			}
			
		});
		
		
		btnMujer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String genero = "Mujer";
				
				if(tipo1 == 0) {
					ArrayList<AtuendosParteArriba> lista = BaseDeDatos.getAtuendosParteArribaPorGenero(genero);
					ModeloParteArriba(lista);
					
				}else if(tipo1 == 1) {
					ArrayList<AtuendosParteAbajo> lista = BaseDeDatos.getAtuendosParteAbajoPorGenero(genero);
					ModeloParteAbajo(lista);
					
				}else {
					ArrayList<AtuendoZapatilla> lista = BaseDeDatos.getZapatillasPorGenero(genero);
					ModeloCalzado(lista);
				}
				
			}
			
		});
		
		

	}
	
	
	
	
	
	

	private void ModeloParteArriba(ArrayList<AtuendosParteArriba> lista) {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "G�nero","Peso", "Color",
				"Material", "Estampado", "Cantidad", "TipoProducto", "Talla"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==0 || column==1 || column==2 || column==3 || column==4 || column==5 || column==6 || column==7 || column==8 || column==9 || column==10 || column==11)
					return false;
				return true;
			}
		};
		
		
		ArrayList<AtuendosParteArriba> productosParteArriba = lista;

	
		for (AtuendosParteArriba producto : productosParteArriba) {
			mDatos.addRow(new Object[] { producto.getId(), producto.getNombre(), producto.getPrecio(),
					producto.getMarca(), producto.getGenero(), producto.getPeso(), producto.getColor(), producto.getMaterial(),
					producto.getEstampado(), producto.getCantidad(), producto.getTipoAtuendo(), producto.getTallaArriba() });
		}

		tDatos.setModel(mDatos);
		
		/*tDatos.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
			
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
				
			}
		});*/
	}
	
	
	
	

	private void ModeloParteAbajo(ArrayList<AtuendosParteAbajo> lista) {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "G�nero", "Peso", "Color",
				"Material", "Estampado", "Cantidad", "Tipo", "Talla"));
		
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==0 || column==1 || column==2 || column==3 || column==4 || column==5 || column==6 || column==7 || column==8 || column==9 || column==10 || column==11)
					return false;
				return true;
			}
		};
		
		
		ArrayList<AtuendosParteAbajo> productosParteAbajo = lista;
		
		for (AtuendosParteAbajo producto : productosParteAbajo) {
			mDatos.addRow(new Object[] { producto.getId(), producto.getNombre(), producto.getPrecio(),
					producto.getMarca(), producto.getGenero(), producto.getPeso(), producto.getColor(), producto.getMaterial(),
					producto.getEstampado(), producto.getCantidad(), producto.getTipo(), producto.getTalla() });
		}
		tDatos.setModel(mDatos);
	}

	private void ModeloCalzado(ArrayList<AtuendoZapatilla> lista) {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "G�nero", "Peso", "Color",
				"Material", "Estampado", "Cantidad", "Talla", "Color", "Tipo"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==0 || column==1 || column==2 || column==3 || column==4 || column==5 || column==6 || column==7 || column==8 || column==9 || column==10 || column==11 || column==12)
					return false;
				return true;
			}
		};
		
		ArrayList<AtuendoZapatilla> productosZapatilla = lista;
		
		for (AtuendoZapatilla producto : productosZapatilla) {
			mDatos.addRow(new Object[] { producto.getId(), producto.getNombre(), producto.getPrecio(),
					producto.getMarca(), producto.getGenero(), producto.getPeso(), producto.getColor(), producto.getMaterial(),
					producto.getEstampado(), producto.getCantidad(), producto.getTalla(), producto.getColorCordon(),producto.getTipo()});
		}
		
		
		tDatos.setModel(mDatos);
	}
	
	
	private void verCarrito() {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("NombreProducto", "Cantidad", "Precio", "Tipo"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==0 || column==1 || column==2 || column==3)
					return false;
				return true;
			}
		};
		ArrayList<Carrito> carrito = BaseDeDatos.getCarrito();
		System.out.println(carrito);
	
		for (Carrito carro : carrito) {
			int precio = carro.getCantidad() * carro.getPrecio();
			mDatos.addRow(new Object[] { carro.getNombre(), carro.getCantidad(), precio, carro.getTipo()});
		}

		tDatos.setModel(mDatos);
	}
	
	private int getTotalCarrito() {
		ArrayList<Carrito> carrito = BaseDeDatos.getCarrito();
		int totalCarrito = 0;
		if(carrito == null) {
			totalCarrito = 0;
		}
		else {
			for (Carrito carro : carrito) {
				totalCarrito += carro.getCantidad() * carro.getPrecio();	
			}
		}
		return totalCarrito;
		
	}
	
	
	private void verCompras() {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Correo Cliente", "NombreProducto", "Cantidad", "Precio", "Tipo", "Fecha Compra", "Fecha Llegada"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==0 || column==1 || column==2 || column==3 || column==4 || column==5 || column==6)
					return false;
				return true;
			}
		};
		String correo = BaseDeDatos.cargarCorreoDeUnCliente();
		ArrayList<Pedido> pedidos = BaseDeDatos.getComprasUsuario(correo);
		
		for (Pedido pedido : pedidos) {
			Date fechaCompra = new Date(pedido.getFechaCompra());
			Date fechaLlegada = new Date(pedido.getFechaLLegada());
			mDatos.addRow(new Object[] { pedido.getCorreoCliente(), pedido.getNombreProducto(), pedido.getCantidad(), pedido.getPrecio(), pedido.getTipo(), fechaCompra, fechaLlegada});
		}

		tDatos.setModel(mDatos);
	}
	
	
private void CrearCarrito() {
		
		int filaSeleccionada = tDatos.getSelectedRow();
		if(filaSeleccionada != -1) {
			int cantidadTabla = (Integer) mDatos.getValueAt(filaSeleccionada, 9);
			int idTabla = (Integer) mDatos.getValueAt(filaSeleccionada, 0);
			String nombre =  (String) mDatos.getValueAt(filaSeleccionada, 1);
			int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Introduce la cantidad del producto"));
			int precio = (Integer) mDatos.getValueAt(filaSeleccionada, 2);
			ArrayList<Carrito> carros = BaseDeDatos.getCarrito();
			ArrayList<String> nombreProductos = new ArrayList();
			for(Carrito carro : carros) {
				nombreProductos.add(carro.getNombre());
			}
			if(cantidadTabla == 0) {
				System.out.println("No queda stock de este producto");
			}
			
			else if(cantidad<cantidadTabla) {
				if(tipo1==0) {
					if(nombreProductos.contains(nombre)) {
						BaseDeDatos.aumentarCantidadCarrito(nombre, cantidad);
						
					}else {
						String tipo = (String) mDatos.getValueAt(filaSeleccionada,10);
						BaseDeDatos.crearCarrito(new Carrito(nombre,cantidad, precio, tipo));
					}
					BaseDeDatos.RestarCantidadDeProductosParteArriba(idTabla, cantidad);
					ModeloParteArriba(BaseDeDatos.getAtuendosParteArriba());

				}else if(tipo1==1){
					if(nombreProductos.contains(nombre)) {
						BaseDeDatos.aumentarCantidadCarrito(nombre, cantidad);
						
					}else {
						String tipo = (String) mDatos.getValueAt(filaSeleccionada,10).toString();
						BaseDeDatos.crearCarrito(new Carrito(nombre,cantidad, precio, tipo));
					}
					BaseDeDatos.RestarCantidadDeProductosParteAbajo(idTabla, cantidad);
					ModeloParteAbajo(BaseDeDatos.getAtuendosParteAbajo());
					
				}else {
					for(Carrito carro : carros) {
						nombreProductos.add(carro.getNombre());
					}
					if(nombreProductos.contains(nombre)) {
						BaseDeDatos.aumentarCantidadCarrito(nombre, cantidad);
						
					}else {
						String tipo = (String) mDatos.getValueAt(filaSeleccionada,11);
						BaseDeDatos.crearCarrito(new Carrito(nombre,cantidad, precio, tipo));
					}
					BaseDeDatos.RestarCantidadDeZapatillas(idTabla, cantidad);
					ModeloCalzado(BaseDeDatos.getZapatillas());
				}
				
			}else {
				JOptionPane.showMessageDialog(null, "La cantidad seleccionada no es posible");
			}

		}else {
			JOptionPane.showMessageDialog(null, "No has seleccionado ningun producto para borrar");
		}

	}
	
	
	//private void realizarCompra(int i) {
		
		//Date f = FechaLlegada.getDate();
		//long fechaLlegada = f.getTime();
		//if(f.toString().isEmpty()) {
		//	JOptionPane.showMessageDialog(null, "No has seleccionado una fecha de llegada");
		//}else {
			//if(i< mDatos.getRowCount()) {
			//	String correo = BaseDeDatos.cargarCorreoDeUnCliente();
			//	System.out.println(correo);
			//	String nombreProducto = (String) mDatos.getValueAt(i, 0);
			//	int cantidad = (Integer) mDatos.getValueAt(i, 1);
			//	int precio = (Integer) mDatos.getValueAt(i, 2);
			//	String tipo = (String) mDatos.getValueAt(i, 3);
			//	long fechaCompra = System.currentTimeMillis();
			//	BaseDeDatos.crearCompra(new Pedido(0, correo, nombreProducto, cantidad, precio, tipo, fechaCompra, fechaLlegada));
			//	mDatos.removeRow(i);
			//	BaseDeDatos.EliminarCarrito();
			//	realizarCompra(i+1);
			//	
			//}
		//}
		
		
		
	//}
	
	private void realizarCompra(int i, PrintWriter pw) {
		
		Date f = FechaLlegada.getDate();
		long fechaLlegada = f.getTime();
		if(f.toString().isEmpty()) {
			JOptionPane.showMessageDialog(null, "No has seleccionado una fecha de llegada");
		}else {
			while(i< mDatos.getRowCount()) {
				String correo = BaseDeDatos.cargarCorreoDeUnCliente();
				String nombreProducto = (String) mDatos.getValueAt(i, 0);
				int cantidad = (Integer) mDatos.getValueAt(i, 1);
				int precio = (Integer) mDatos.getValueAt(i, 2);
				String tipo = (String) mDatos.getValueAt(i, 3);
				long fechaCompra = System.currentTimeMillis();
				BaseDeDatos.crearCompra(new Pedido(0, correo, nombreProducto, cantidad, precio, tipo, fechaCompra, fechaLlegada));
				System.out.println(f);
				System.out.println(fechaCompra);
				pw.println(correo+"\t"+nombreProducto+"\t"+cantidad+"\t"+precio+"\t"+tipo+"\t"+fechaCompra+"\t"+fechaLlegada);
				mDatos.removeRow(i);
				BaseDeDatos.EliminarCarrito();
				realizarCompra(i+1, pw);
				
			}
		}
		
	}
	
	private float calcularCoste(int i, int costeTotal) {
		if(i<mDatos.getRowCount()) {
			int precio = (Integer) mDatos.getValueAt(i, 2);
			return calcularCoste(i+1, precio + costeTotal);
		}else {
			return costeTotal;
		}
	}
	

	public static void main(String[] args) {
		VentanaUsuario ventana = new VentanaUsuario();
		ventana.setVisible(true);
	}
	
	
}
