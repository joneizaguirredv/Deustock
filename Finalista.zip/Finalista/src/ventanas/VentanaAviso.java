package ventanas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VentanaAviso extends JFrame {
	private JLabel Texto;
	private JButton botonAceptar;
	private JButton botonVolver;
	private JPanel pSur;
	private JPanel pCentro;

	public VentanaAviso() {

		this.setTitle("Aviso");
		this.setSize(300, 100);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setResizable(false);
		this.setLocationRelativeTo(null);

		botonAceptar = new JButton("Aceptar");
		botonVolver = new JButton("Volver");
		Texto = new JLabel("¿Desea que esta pagina se cierre?");

		pSur = new JPanel(new FlowLayout());
		pCentro = new JPanel(new FlowLayout());

		pSur.add(botonAceptar);
		pSur.add(botonVolver);
		pCentro.add(Texto);

		this.add(pSur, BorderLayout.SOUTH);
		this.add(pCentro, BorderLayout.CENTER);

		botonAceptar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();

			}

		});

		botonVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaCoockies ventana = new VentanaCoockies();
				ventana.setVisible(true);

			}

		});

	}

}