package ventanas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VentanaPagoHabitual extends JFrame{
	private JFrame frmVentanaPagoHabitual;
	private JLabel habitual;
	private JButton btnAceptar;
	private JButton btnDenegar;
	private JPanel pNorte;
	private JPanel pSur;
	private JPanel pCentro;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPagoHabitual window = new VentanaPagoHabitual();
					window.frmVentanaPagoHabitual.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public VentanaPagoHabitual() {
		//BaseDeDatos.inicioConexion("BaseDeDatos1.db");
		initialize();
	}
		private void initialize() {
		
		frmVentanaPagoHabitual = new JFrame();
		frmVentanaPagoHabitual.setTitle("Metodo de pago");
		frmVentanaPagoHabitual.getContentPane().setBackground(new Color(0xa8ccba));
		//this.setSize(400, 100);
		frmVentanaPagoHabitual.setBounds(200, 200, 500, 190);
		frmVentanaPagoHabitual.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frmVentanaPagoHabitual.getContentPane().setLayout(null);
	
	
		habitual = new JLabel("Desea utilizar el metodo de pago y cuenta bancaria habituales?");
		habitual.setBounds(60, 5, 500, 80);
		frmVentanaPagoHabitual.getContentPane().add(habitual);
		btnAceptar = new JButton("Aceptar");
		btnAceptar.setBounds(100, 90, 119, 30);
		btnAceptar.setForeground(Color.WHITE);
		btnAceptar.setBackground(SystemColor.desktop);
		frmVentanaPagoHabitual.getContentPane().add(btnAceptar);
		btnDenegar = new JButton("Rechazar");
		btnDenegar.setBounds(250, 90, 119, 30);
		btnDenegar.setForeground(Color.WHITE);
		btnDenegar.setBackground(SystemColor.desktop);
		frmVentanaPagoHabitual.getContentPane().add(btnDenegar);
		
		
		//pSur = new JPanel(new FlowLayout());
		//pCentro = new JPanel(new FlowLayout());
		
		//pSur.add(btnAceptar);
		//pSur.add(btnDenegar);
		//pCentro.add(habitual);
		
		//this.add(pSur, BorderLayout.SOUTH);
		//this.add(pCentro, BorderLayout.CENTER);
		
		btnDenegar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				new VentanaPago();

			}
		});
		
		btnAceptar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				new VentanaPagoCliente();

			}
		});
		
		frmVentanaPagoHabitual.setVisible(true);
	
	
	}
	
	
}
