package BaseDeDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import clases.AtuendosParteAbajo;
import clases.AtuendosParteArriba;
import clases.Carrito;
import clases.Cliente;
import clases.Pago;
import clases.Pedido;
import clases.Administrador;
import clases.AtuendoZapatilla;
import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;
import enumeraciones.TipoPantalon;
import enumeraciones.TipoZapatilla;

public class BaseDeDatos {
	private static Connection conexion;
	private static Logger logger = Logger.getLogger("BaseDeDatos");

	public static boolean inicioConexion(String nombreBD) {
		try {
			// No terminado
			conexion = DriverManager.getConnection("jdbc:sqlite:" + nombreBD);
			Statement statement = conexion.createStatement();
			
			
			  String sent = "DROP TABLE IF EXISTS productoarriba";
			  logger.log( Level.INFO, "Statement: " + sent);
			  statement.executeUpdate(sent);
 
			  sent ="CREATE TABLE IF NOT EXISTS productoarriba(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre varchar(100), precio int(7),"
			  +
			  "marca varchar(15), genero varchar(15), peso int(10), color varchar(10), material varchar(10), estampado boolean, cantidad int(10), tipoProducto varchar(20), talla varchar(3));"; 
			  logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent);
			 
			  
			  sent = "DROP TABLE IF EXISTS productoAbajo";
			  logger.log( Level.INFO, "Statement: " + sent);
			  statement.executeUpdate(sent);
				 
			  
			  sent = "CREATE TABLE IF NOT EXISTS productoAbajo (id INTEGER PRIMARY KEY, nombre varchar(100), precio int(7),"
			  +
			  "marca varchar(15), genero varchar(15), peso int(10), color varchar(10), material varchar(10), estampado boolean, cantidad int(10), tipo varchar(10), talla varchar(3));"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  
			  sent = "DROP TABLE IF EXISTS productoZapatilla";
			  logger.log( Level.INFO, "Statement: " + sent);
			  statement.executeUpdate(sent);
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS productoZapatilla (id INTEGER PRIMARY KEY, nombre varchar(100), precio int(7),"
			  +
			  "marca varchar(15), genero varchar(15), peso int(10), color varchar(10), material varchar(10), estampado boolean, cantidad int(10), talla int(2), colorCordon varchar(10), tipo varchar(10));"
			  ; logger.log( Level.INFO, "Statement: " + sent );
			  statement.executeUpdate(sent );
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS cliente(id INTEGER PRIMARY KEY AUTOINCREMENT, correo varchar(50), nombre varchar(15), apellido varchar(40), contrase�a varchar(30), telefono int(9), codigoPostal int(5));"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS administrador(id INTEGER PRIMARY KEY AUTOINCREMENT, correo varchar(50), nombre varchar(15), apellido varchar(40), contrase�a varchar(30), NSS varchar(12));"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  
			  sent = "DROP TABLE IF EXISTS carrito";
			  logger.log( Level.INFO, "Statement: " + sent);
			  statement.executeUpdate(sent);
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS carrito(Nombre VARCHAR(30) PRIMARY KEY, cantidad int(3), precio int(3), tipo varchar(30));"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS cogerCliente(correoCliente varchar(30) PRIMARY KEY);"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			 
					  
			  
			  sent ="CREATE TABLE IF NOT EXISTS compra(idCompra INTEGER PRIMARY KEY, correoCliente Varchar(30), nombreProducto varchar(30), cantidad int(3), precio int(3), tipo varchar(30), fechaCompra long, fechaLlegada long);"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  
			  sent ="CREATE TABLE IF NOT EXISTS pago(id INTEGER PRIMARY KEY AUTOINCREMENT, correo varchar(50), nombre varchar(15), apellido varchar(40), contrase�a varchar(30), cuentaBancaria varchar(16), caducidad varchar(5), cvv varchar(3));"
			  ; logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate(sent );
			  
			  try { Scanner scanner = new Scanner(BaseDeDatos.class.getResourceAsStream("productoArriba.txt") );
			  while (scanner.hasNextLine()) { //Mientras en el fichero haya lineas que leer
			  String linea = scanner.nextLine(); //Lee una linea del fichero String[] datos
			  String[] datos = linea.split( "\t" );
			  sent = "insert into productoarriba (id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad, tipoProducto, talla) values (" +
			  datos[0] + ",'" + datos[1] + "'," + datos[2] + ",'" + datos[3] + "','" +
			  datos[4] + "'," + datos[5] + ",'" + datos[6] + "','" + datos[7] + "'," + datos[8]
			  + "," + datos[9] + ",'" + datos[10] + "','" + datos[11] + "');"; 
			  logger.log( Level.INFO, "Statement: " + sent );
			  statement.executeUpdate( sent ); }
			  scanner.close();
			  
			  
			  scanner = new Scanner(
			  BaseDeDatos.class.getResourceAsStream("productoAbajo.txt") );
			  while (scanner.hasNextLine()) { String linea = scanner.nextLine();
			  String[] datos = linea.split( "\t" ); 
			  sent = "insert into productoAbajo (id, nombre , precio, marca, genero, peso, color, material, estampado, cantidad, tipo, talla) values (" +
			  datos[0] + ",'" + datos[1] + "'," + datos[2] + ",'" + datos[3] + "','" +
			  datos[4] + "'," + datos[5] + ",'" + datos[6] + "','" + datos[7] + "'," + datos[8]
			  + "," + datos[9] + ",'" + datos[10] + "','" + datos[11] + "');";
			  logger.log( Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate( sent ); }
			  scanner.close();
			  
			  
			  scanner = new Scanner(
			  BaseDeDatos.class.getResourceAsStream("productoZapatilla.txt") ); while
			  (scanner.hasNextLine()) { String linea = scanner.nextLine(); 
			  String[] datos = linea.split( "\t" ); 
			  sent = "insert into productoZapatilla (id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad, talla, colorCordon, tipo) values (" +
			  datos[0] + ",'" + datos[1] + "'," + datos[2] + ",'" + datos[3] + "','" +
			  datos[4] + "'," + datos[5] + ",'" + datos[6] + "','" + datos[7] + "'," + datos[8]
			  + "," + datos[9] + "," + datos[10] + ",'" + datos[11] + "','" + datos[12] +"');"; 
			  logger.log(Level.INFO, "Statement: " + sent ); 
			  statement.executeUpdate( sent ); }
			  scanner.close();
			  
			  
					  
			  
			  
			  } catch(Exception e) { logger.log( Level.SEVERE, "Excepción", e ); }
			 

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public static void cerrarConexion() {
		try {
			logger.log(Level.INFO, "Cerrando conexión");
			conexion.close();
		} catch (SQLException e) {
			logger.log(Level.SEVERE, "Excepción", e);
		}
	}

	public static ArrayList<AtuendosParteArriba> getAtuendosParteArriba() {
		ArrayList<AtuendosParteArriba> ret = new ArrayList<>();
		try (Statement statement = conexion.createStatement()) {
			String sent = "select * from productoarriba;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String tipo = rs.getString("tipoProducto");
				ret.add(new AtuendosParteArriba(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad, tipo, TallaParteArribaYAbajo.valueOf(talla)));
				
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	
	public static ArrayList<AtuendosParteArriba> getAtuendosParteArribaOrdenado(String ordenar) {
		ArrayList<AtuendosParteArriba> ret = new ArrayList<>();
		try (Statement statement = conexion.createStatement()) {
			String sent = "select * from productoarriba order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String tipo = rs.getString("tipoProducto");
				ret.add(new AtuendosParteArriba(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad, tipo, TallaParteArribaYAbajo.valueOf(talla)));
				
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	public static ArrayList<AtuendosParteArriba> getAtuendosParteArribaPorTipo(String tipo) {
		ArrayList<AtuendosParteArriba> ret = new ArrayList<>();
		try (Statement statement = conexion.createStatement()) {
			String sent = "select * from productoarriba where tipoProducto= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String tipoProducto = rs.getString("tipoProducto");
				ret.add(new AtuendosParteArriba(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad, tipoProducto, TallaParteArribaYAbajo.valueOf(talla)));
				
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	

	public static ArrayList<AtuendosParteArriba> getAtuendosParteArribaPorGenero(String tipo) {
		ArrayList<AtuendosParteArriba> ret = new ArrayList<>();
		try (Statement statement = conexion.createStatement()) {
			String sent = "select * from productoarriba where genero= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String tipoProducto = rs.getString("tipoProducto");
				ret.add(new AtuendosParteArriba(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad, tipoProducto, TallaParteArribaYAbajo.valueOf(talla)));
				
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	
	public static ArrayList<AtuendosParteArriba> getAtuendosParteArribaPorTipoYOrdenado(String ordenar, String tipo) {
		ArrayList<AtuendosParteArriba> ret = new ArrayList<>();
		try (Statement statement = conexion.createStatement()) {
			String sent = "select * from productoarriba where tipoProducto= '" +tipo+"' order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String tipoProducto = rs.getString("tipoProducto");
				ret.add(new AtuendosParteArriba(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad, tipoProducto, TallaParteArribaYAbajo.valueOf(talla)));
				
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	

	public static ArrayList<AtuendosParteAbajo> getAtuendosParteAbajo() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendosParteAbajo> ret = new ArrayList<>();
			String sent = "select * from productoAbajo;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String tipo = rs.getString("tipo");
				String talla = rs.getString("talla");
				ret.add(new AtuendosParteAbajo(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						TipoPantalon.valueOf(tipo), TallaParteArribaYAbajo.valueOf(talla)));
			}
			return ret;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	public static ArrayList<AtuendosParteAbajo> getAtuendosParteAbajoOrdenado(String ordenar) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendosParteAbajo> ret = new ArrayList<>();
			String sent = "select * from productoAbajo order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String tipo = rs.getString("tipo");
				String talla = rs.getString("talla");
				ret.add(new AtuendosParteAbajo(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						TipoPantalon.valueOf(tipo), TallaParteArribaYAbajo.valueOf(talla)));
			}
			return ret;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	
	public static ArrayList<AtuendosParteAbajo> getAtuendosParteAbajoPorTipo(String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendosParteAbajo> ret = new ArrayList<>();
			String sent = "select * from productoAbajo where tipo= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String tipoAtuendo = rs.getString("tipo");
				String talla = rs.getString("talla");
				ret.add(new AtuendosParteAbajo(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						TipoPantalon.valueOf(tipoAtuendo), TallaParteArribaYAbajo.valueOf(talla)));
			}
			return ret;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	public static ArrayList<AtuendosParteAbajo> getAtuendosParteAbajoPorGenero(String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendosParteAbajo> ret = new ArrayList<>();
			String sent = "select * from productoAbajo where genero= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String tipoAtuendo = rs.getString("tipo");
				String talla = rs.getString("talla");
				ret.add(new AtuendosParteAbajo(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						TipoPantalon.valueOf(tipoAtuendo), TallaParteArribaYAbajo.valueOf(talla)));
			}
			
			return ret;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	public static ArrayList<AtuendosParteAbajo> getAtuendosParteAbajoPorTipoYOrdenado(String ordenar, String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendosParteAbajo> ret = new ArrayList<>();
			String sent = "select * from productoAbajo where tipo= '" +tipo+"' order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String tipoAtuendo = rs.getString("tipo");
				String talla = rs.getString("talla");
				ret.add(new AtuendosParteAbajo(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						TipoPantalon.valueOf(tipoAtuendo), TallaParteArribaYAbajo.valueOf(talla)));
			}
			
			return ret;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	

	public static ArrayList<AtuendoZapatilla> getZapatillas() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendoZapatilla> ret = new ArrayList<>();
			String sent = "select * from productoZapatilla;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String colorCordon = rs.getString("colorCordon");
				String tipo = rs.getString("tipo");
				ret.add(new AtuendoZapatilla(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						talla, colorCordon, TipoZapatilla.valueOf(tipo)));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<AtuendoZapatilla> getZapatillasOrdenado(String ordenar) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendoZapatilla> ret = new ArrayList<>();
			String sent = "select * from productoZapatilla order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String colorCordon = rs.getString("colorCordon");
				String tipo = rs.getString("tipo");
				ret.add(new AtuendoZapatilla(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						talla, colorCordon, TipoZapatilla.valueOf(tipo)));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<AtuendoZapatilla> getZapatillasPorTipo(String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendoZapatilla> ret = new ArrayList<>();
			String sent = "select * from productoZapatilla where tipo= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String colorCordon = rs.getString("colorCordon");
				String tipoAtuendo = rs.getString("tipo");
				ret.add(new AtuendoZapatilla(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						talla, colorCordon, TipoZapatilla.valueOf(tipoAtuendo)));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<AtuendoZapatilla> getZapatillasPorGenero(String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendoZapatilla> ret = new ArrayList<>();
			String sent = "select * from productoZapatilla where genero= '" +tipo+"';";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String colorCordon = rs.getString("colorCordon");
				String tipoAtuendo = rs.getString("tipo");
				ret.add(new AtuendoZapatilla(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						talla, colorCordon, TipoZapatilla.valueOf(tipoAtuendo)));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<AtuendoZapatilla> getZapatillasPorTipoYOrdenados(String ordenar, String tipo) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<AtuendoZapatilla> ret = new ArrayList<>();
			String sent = "select * from productoZapatilla where tipo= '" +tipo+"' order by "+ordenar+";";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				int precio = rs.getInt("precio");
				String marca = rs.getString("marca");
				String genero = rs.getString("genero");
				int peso = rs.getInt("peso");
				String color = rs.getString("color");
				String material = rs.getString("material");
				Boolean estampado = rs.getBoolean("estampado");
				int cantidad = rs.getInt("cantidad");
				String talla = rs.getString("talla");
				String colorCordon = rs.getString("colorCordon");
				String tipoAtuendo = rs.getString("tipo");
				ret.add(new AtuendoZapatilla(id, nombre, precio, MarcasProductos.valueOf(marca), genero, peso, color, material, estampado, cantidad,
						talla, colorCordon, TipoZapatilla.valueOf(tipoAtuendo)));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<Pedido> getComprasUsuario(String correoCliente) {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<Pedido> ret = new ArrayList<>();
			String sent = "select * from compra where correoCliente='" + correoCliente + "'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int id = rs.getInt("idCompra");
				String correo = rs.getString("correoCliente");
				String nombre = rs.getString("nombreProducto");
				int cantidad = rs.getInt("cantidad");
				int precio = rs.getInt("precio");
				String tipo = rs.getString("tipo");
				long fechaCompra = rs.getLong("fechaCompra");
				long fechaLlegada = rs.getLong("fechaLlegada");
				
				ret.add(new Pedido(id, correo, nombre, cantidad, precio, tipo, fechaCompra, fechaLlegada));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	
	public static ArrayList<Carrito> getCarrito(){
		try (Statement statement = conexion.createStatement()) {
			ArrayList<Carrito> ret = new ArrayList<>();
			String sent = "select * from carrito;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int cantidad = rs.getInt("cantidad");
				String nombre = rs.getString("Nombre");
				int precio = rs.getInt("precio");
				String tipo = rs.getString("tipo");
				
				ret.add(new Carrito(nombre, cantidad, precio, tipo));
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	public static int getLengthCarrito(){
		try (Statement statement = conexion.createStatement()) {
			int ret = 0;
			String sent = "select count(*) from carrito;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) {
				int count = rs.getInt("count(*)");	
				ret = count;
			}
			return ret;
		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "Excepción", e);
			return 0;
		}
	}
	
	
	
	public static void crearCarrito(Carrito carro) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into carrito (Nombre, cantidad, precio, tipo) values('" + carro.getNombre() + "',"
					+ carro.getCantidad() + ", " + carro.getPrecio() +", '" + carro.getTipo() + "')";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void aumentarCantidadCarrito(String nombre, int cantidad) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "update carrito set cantidad = cantidad + "+cantidad+" where nombre = '"+nombre+"'";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
	public static ArrayList<String> getAdministradores() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<String> ret = new ArrayList<>();
			String sent = "select correo from administrador;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String correo = rs.getString("correo");
				ret.add(correo);
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	public static String getContrase�aAdministrador(String usuario) {
		try (Statement statement = conexion.createStatement()) {
			String contrase�aDev = "";
			String sent = "select contrase�a from administrador where correo='"+usuario+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String contrase�a = rs.getString("contrase�a");
				contrase�aDev = contrase�a;
			}
			
			return contrase�aDev;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static void crearCliente(Cliente cliente) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into cliente (correo, nombre, apellido, contrase�a, telefono, codigoPostal) values('" + cliente.getCorreo() + "','"
					+ cliente.getNombre() + "','" + cliente.getApellido() + "','" + cliente.getContrase�a() + "', "
					+ cliente.getTelefono() + "," + cliente.getCodigoPostal() + ")";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void crearPago(Pago pago) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into pago (correo, nombre, apellido, contrase�a, cuentaBancaria, caducidad, cvv) values('" + pago.getCorreo() + "','"
					+ pago.getNombre() + "','" + pago.getApellido() + "','" + pago.getContrase�a() + "', "
					+ pago.getCuentaBancaria() + "," + pago.getCaducidad() + "," + pago.getCvv() + ")";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static ArrayList<Pago> getPagos() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<Pago> ret = new ArrayList<>();
			String sent = "select * from pago;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				String correo = rs.getString("correo");
				String nombre = rs.getString("nombre");
				String apellido = rs.getString("apellido");
				String contrase�a = rs.getString("contrase�a");
				String cuentaBancaria = rs.getString("cuentaBancaria");
				String caducidad = rs.getString("caducidad");
				String cvv = rs.getString("cvv");
				
				ret.add(new Pago(id, correo, nombre, apellido, contrase�a, cuentaBancaria, caducidad, cvv));
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	public static ArrayList<String> getCaducidades() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<String> ret = new ArrayList<>();
			String sent = "select caducidad from pago;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String caducidad = rs.getString("caducidad");
				ret.add(caducidad);
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	public static ArrayList<String> getCorreosPagos() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<String> ret = new ArrayList<>();
			String sent = "select correo from pago;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String correo = rs.getString("correo");
				ret.add(correo);
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	
	public static String getContrase�aCliente(String usuario) {
		try (Statement statement = conexion.createStatement()) {
			String contrase�aDev = "";
			String sent = "select contrase�a from cliente where correo='"+usuario+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String contrase�a = rs.getString("contrase�a");
				contrase�aDev = contrase�a;
			}
			
			return contrase�aDev;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	
	public static ArrayList<String> getClientes() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<String> ret = new ArrayList<>();
			String sent = "select correo from cliente;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String correo = rs.getString("correo");
				ret.add(correo);
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	public static void almacenarClienteVentana(String correo) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into cogerCliente (correoCliente) values('" + correo + "')";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public static String cargarCorreoDeUnCliente() {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select correoCliente from cogerCliente;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String correo = rs.getString("correoCliente");
				ret = correo;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	public static int cargarIdDeUnCliente() {
		try (Statement statement = conexion.createStatement()) {
			int ret = 0;
			String sent = "select id from cliente;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				int id = rs.getInt("id");
				ret = id;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return 0;
		}
	}
	
	
	public static String cargarNombreDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select nombre from cliente where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String nombre = rs.getString("nombre");
				ret = nombre;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	public static String cargarApellidoDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select apellido from cliente where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String apellido = rs.getString("apellido");
				ret = apellido;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	public static String cargarContrase�aDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select contrase�a from cliente where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String contrase�a = rs.getString("contrase�a");
				ret = contrase�a;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	public static String cargarCuentaBancariaDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select cuentaBancaria from pago where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String cuentaBancaria = rs.getString("cuentaBancaria");
				ret = cuentaBancaria;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	public static String cargarCaducidadDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select caducidad from pago where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String caducidad = rs.getString("caducidad");
				ret = caducidad;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	public static String cargarCvvDeUnCliente(String correo) {
		try (Statement statement = conexion.createStatement()) {
			String ret = "";
			String sent = "select cvv from pago where correo = '"+correo+"'";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				String cvv = rs.getString("cvv");
				ret = cvv;
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}
	}
	
	
	public static ArrayList<Integer> getCantidad() {
		try (Statement statement = conexion.createStatement()) {
			ArrayList<Integer> ret = new ArrayList<>();
			String sent = "select cantidad from productoarriba;";
			logger.log(Level.INFO, "Statement: " + sent);
			ResultSet rs = statement.executeQuery(sent);
			while (rs.next()) { // Leer el resultset
				System.out.println("entra");
				int cantidad = rs.getInt("cantidad");
				System.out.println("a�adido");
				ret.add(cantidad);
			}
			return ret;
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Excepción", e);
			return null;
		}

	}
	
	
	
	
	
	
	

	public static void crearAtuendoParteArriba(AtuendosParteArriba atuendo) {
		try (Statement statement = conexion.createStatement();) {
			String talla = atuendo.getTallaArriba().toString();
			String sent = "insert into productoarriba (nombre, precio, marca, peso, color, material, estampado, cantidad, tipoProducto, talla) values('" + atuendo.getNombre() + "',"
					+ atuendo.getPrecio() + ",'" + atuendo.getMarca() + "'," + atuendo.getPeso() + ", '"
					+ atuendo.getColor() + "','" + atuendo.getMaterial() + "', " + atuendo.getEstampado() + ","
					+ atuendo.getCantidad() + ",'" + atuendo.getTipoAtuendo() + "','" + talla + "')";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void crearAtuendoParteAbajo(AtuendosParteAbajo atuendo) {
		try (Statement statement = conexion.createStatement();) {
			String talla = atuendo.getTalla().toString();
			String tipo = atuendo.getTipo().toString();
			String sent = "insert into productoAbajo (nombre, precio, marca, peso, color, material, estampado, cantidad, tipo, talla) values('" + atuendo.getNombre() + "',"
					+ atuendo.getPrecio() + ",'" + atuendo.getMarca() + "'," + atuendo.getPeso() + ", '"
					+ atuendo.getColor() + "','" + atuendo.getMaterial() + "'," + atuendo.getEstampado() + ","
					+ atuendo.getCantidad() + ",'" + tipo + "','" + talla + "')";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void crearAtuendoZapatilla(AtuendoZapatilla atuendo) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into productoZapatilla (nombre, precio, marca, peso, color, material, estampado, cantidad, talla, colorCordon, tipo) values('" + atuendo.getNombre() + "',"
					+ atuendo.getPrecio() + ",'" + atuendo.getMarca() + "'," + atuendo.getPeso() + ", '"
					+ atuendo.getColor() + "','" + atuendo.getMaterial() + "'," + atuendo.getEstampado() + ","
					+ atuendo.getCantidad() + "," + atuendo.getTalla() + ",'" + atuendo.getColorCordon() + "','"
					+ atuendo.getTipo() + "')";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void crearCompra(Pedido pedido) {
		try (Statement statement = conexion.createStatement();) {
			String sent = "insert into compra (correoCliente, nombreProducto, cantidad, precio, tipo, fechaCompra, fechaLlegada) values('" + pedido.getCorreoCliente() + "','"
					+ pedido.getNombreProducto() + "'," + pedido.getCantidad() + "," + pedido.getPrecio() + ", '"
					+ pedido.getTipo() + "'," + pedido.getFechaCompra() + "," + pedido.getFechaLLegada() + ")";
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public static void BorrarProductoParteArriba(int id) {
		try {
			Statement statement = conexion.createStatement();
			System.out.println("has entrado");
			String sent = "delete from productoarriba where id = "+id;
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void BorrarProductoParteAbajo(int id) {
		try {
			Statement statement = conexion.createStatement();
			String sent = "delete from productoAbajo where id = "+id;
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void BorrarProductoZapatilla(int id) {
		try {
			Statement statement = conexion.createStatement();
			String sent = "delete from productoZapatilla where id = "+id;
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void modificarAtuendoParteArriba(AtuendosParteArriba producto) {
		try {
			Statement statement = conexion.createStatement();
			String marca = producto.getMarca().toString();
			String talla = producto.getTallaArriba().toString();
			String sent = "update productoArriba set nombre='"+producto.getNombre()+"',precio="+producto.getPrecio()+""
					+ ",marca='"+marca+"',genero='"+producto.getGenero()+"',peso=" +producto.getPeso()+",color='" +producto.getColor()+"',material='"
					+producto.getMaterial()+"',estampado=" +producto.getEstampado()+",cantidad=" +producto.getCantidad()+",tipoProducto='"
					+ producto.getTipoAtuendo() +"',talla='" +talla+"' where id="+producto.getId();
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void modificarAtuendoParteAbajo(AtuendosParteAbajo producto) {
		try {
			Statement statement = conexion.createStatement();
			String marca = producto.getMarca().toString();
			String talla = producto.getTalla().toString();
			String sent = "update productoAbajo set nombre='"+producto.getNombre()+"',precio="+producto.getPrecio()+""
					+ ",marca='"+marca+"',genero='"+producto.getGenero()+"',peso=" +producto.getPeso()+",color='" +producto.getColor()+"',material='"
					+producto.getMaterial()+"',estampado=" +producto.getEstampado()+",cantidad=" +producto.getCantidad()+",tipo='"
					+ producto.getTipo() +"',talla='" +talla+"' where id="+producto.getId();
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public static void modificarZapatillas(AtuendoZapatilla producto) {
		try {
			Statement statement = conexion.createStatement();
			String marca = producto.getMarca().toString();
			String talla = producto.getTalla().toString();
			String sent = "update productoZapatilla set nombre='"+producto.getNombre()+"',precio="+producto.getPrecio()+""
					+ ",marca='"+marca+"',genero='"+producto.getGenero()+"',peso=" +producto.getPeso()+",color='" +producto.getColor()+"',material='"
					+producto.getMaterial()+"',estampado=" +producto.getEstampado()+",cantidad=" +producto.getCantidad()+",talla='"
					+ producto.getTalla() +"',colorCordon='" +producto.getColorCordon()+"',tipo='" +talla+"' where id="+producto.getId();
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	public static void RestarCantidadDeProductosParteArriba(int id, int cantidad) {
		try {
			Statement statement = conexion.createStatement();
			String sent = "update productoarriba set cantidad = cantidad - "+cantidad+ " where id=" +id;
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void RestarCantidadDeProductosParteAbajo(int id, int cantidad) {
		try {
			Statement statement = conexion.createStatement();
			String sent = "update productoAbajo set cantidad = cantidad - "+cantidad+ " where id=" +id;
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public static void RestarCantidadDeZapatillas(int id, int cantidad) {
		try {
			Statement statement = conexion.createStatement();
			String sent = "update productoZapatilla set cantidad = cantidad - "+cantidad+ " where id=" +id;
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void EliminarUsuarioDeBaseDeDatos() {
		try{
			Statement statement = conexion.createStatement();
			String sent = "delete from cogerCliente;";
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void EliminarCarrito() {
		try{
			Statement statement = conexion.createStatement();
			String sent = "delete from carrito;";
			logger.log(Level.INFO, "Statement: " + sent);
			statement.executeUpdate(sent);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}


//Se puede meter el carrito en otra ventana
//Multiples opciones en el JOptionPane
//Ventana de inicio de sesion
//Relacionar la compra con los productos