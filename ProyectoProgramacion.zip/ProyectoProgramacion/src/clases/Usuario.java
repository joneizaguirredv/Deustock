package clases;

import java.util.regex.Pattern;

import excepciones.MiExcepcionExplicita;
import interfaces.I;

public class Usuario implements I {
	private int Id;
	private String Correo;
	private String Contrase�a;
	private String Nombre;
	private String Apellido;

	public Usuario(int id, String correo, String contrase�a, String nombre, String apellido) throws MiExcepcionExplicita {
		super();
		Id = id;
		String er = "[A-Za-z]@gmail.com";
		boolean correoCorrecto = Pattern.matches(er, correo);
		if (!correoCorrecto) {
			throw new MiExcepcionExplicita("El correo no tiene el formato adecuado");
		}
		Correo = correo;
		Contrase�a = contrase�a;
		Nombre = nombre;
		Apellido = apellido;
	}

	

	public int getId() {
		return Id;
	}



	public void setId(int id) {
		Id = id;
	}



	public String getCorreo() {
		return Correo;
	}



	public void setCorreo(String correo) {
		Correo = correo;
	}



	public String getContrase�a() {
		return Contrase�a;
	}



	public void setContrase�a(String contrase�a) {
		Contrase�a = contrase�a;
	}



	public String getNombre() {
		return Nombre;
	}



	public void setNombre(String nombre) {
		Nombre = nombre;
	}



	public String getApellido() {
		return Apellido;
	}



	public void setApellido(String apellido) {
		Apellido = apellido;
	}



	@Override
	public boolean puedeEditar() {
		// TODO Auto-generated method stub
		return false;
	}

}