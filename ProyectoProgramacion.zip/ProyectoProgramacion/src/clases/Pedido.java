package clases;

import java.util.ArrayList;

public class Pedido {
	private int IdPedido;
	private String CorreoCliente;
	private String NombreProducto;
	private int Cantidad;
	private int Precio;
	private String Tipo;
	private long FechaCompra;
	private long FechaLLegada;
	
	
	
	public Pedido(int idPedido, String correoCliente, String nombreProducto, int cantidad, int precio, String tipo,
			long fechaCompra, long fechaLLegada) {
		super();
		IdPedido = idPedido;
		CorreoCliente = correoCliente;
		NombreProducto = nombreProducto;
		Cantidad = cantidad;
		Precio = precio;
		Tipo = tipo;
		FechaCompra = fechaCompra;
		FechaLLegada = fechaLLegada;
	}



	public int getIdPedido() {
		return IdPedido;
	}



	public void setIdPedido(int idPedido) {
		IdPedido = idPedido;
	}



	public String getCorreoCliente() {
		return CorreoCliente;
	}



	public void setCorreoCliente(String correoCliente) {
		CorreoCliente = correoCliente;
	}



	public String getNombreProducto() {
		return NombreProducto;
	}



	public void setNombreProducto(String nombreProducto) {
		NombreProducto = nombreProducto;
	}



	public int getCantidad() {
		return Cantidad;
	}



	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}



	public int getPrecio() {
		return Precio;
	}



	public void setPrecio(int precio) {
		Precio = precio;
	}



	public String getTipo() {
		return Tipo;
	}



	public void setTipo(String tipo) {
		Tipo = tipo;
	}



	public long getFechaCompra() {
		return FechaCompra;
	}



	public void setFechaCompra(long fechaCompra) {
		FechaCompra = fechaCompra;
	}



	public long getFechaLLegada() {
		return FechaLLegada;
	}



	public void setFechaLLegada(long fechaLLegada) {
		FechaLLegada = fechaLLegada;
	}
	
	
	
	
	
	
	


}