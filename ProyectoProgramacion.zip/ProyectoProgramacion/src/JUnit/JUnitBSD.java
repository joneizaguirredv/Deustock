package JUnit;

import static org.junit.Assert.*;

import java.sql.Connection;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import BaseDeDatos.BaseDeDatos;
import clases.AtuendoZapatilla;
import clases.AtuendosParteAbajo;
import clases.AtuendosParteArriba;
import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;
import enumeraciones.TipoPantalon;
import enumeraciones.TipoZapatilla;



public class JUnitBSD {
private Connection conexion;

@Before
public void before() throws Exception {
BaseDeDatos.inicioConexion("BaseDeDatos1.db");
}

@After
public void after() throws Exception {
BaseDeDatos.cerrarConexion();
}


@Test
public void testInsertarAtuendoAbajo() {
ArrayList<AtuendosParteAbajo> ALParteAbajo1 = BaseDeDatos.getAtuendosParteAbajo();
BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(5, "pantalon alto", 75, MarcasProductos.ZARA, "Mujer", 400, "blanco", "lana", true, 1, TipoPantalon.CAMPANA, TallaParteArribaYAbajo.S));
BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(6, "pantalon pirata", 50, MarcasProductos.ELLESE, "Hombre", 420, "azul", "seda", false, 3, TipoPantalon.NORMAL, TallaParteArribaYAbajo.L));
BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(7, "pantalon corto", 55, MarcasProductos.LEVIS, "Unisex", 515, "azul", "lana", true, 2, TipoPantalon.PITILLO, TallaParteArribaYAbajo.XLL));
ArrayList<AtuendosParteAbajo> ALParteAbajo2 = BaseDeDatos.getAtuendosParteAbajo();
// tres productos a�adidos
assertTrue(ALParteAbajo1.size() +3 == ALParteAbajo2.size());

}

@Test
public void testInsertarAtuendoAbajoOrdenado() {
ArrayList<AtuendosParteAbajo> ALParteAbajoOrdId = BaseDeDatos.getAtuendosParteAbajoOrdenado("id");
ArrayList<AtuendosParteAbajo> ALParteAbajoOrdCantidad = BaseDeDatos.getAtuendosParteAbajoOrdenado("cantidad");
ArrayList<AtuendosParteAbajo> ALParteAbajoOrdPrecio = BaseDeDatos.getAtuendosParteAbajoOrdenado("precio");
ArrayList<AtuendosParteAbajo> ALParteAbajoOrdPeso = BaseDeDatos.getAtuendosParteAbajoOrdenado("peso");
int codMayor1 = 0;
int codMayor2 = 0;
int codMayor3 = 0;
int codMayor4 = 0;
for (AtuendosParteAbajo a : ALParteAbajoOrdId) {
assertTrue(a.getId()>=codMayor1);
codMayor1 = a.getId();
}
for (AtuendosParteAbajo a : ALParteAbajoOrdCantidad) {
assertTrue(a.getCantidad()>=codMayor2);
codMayor2 = a.getCantidad();
}
for (AtuendosParteAbajo a : ALParteAbajoOrdPrecio) {
assertTrue(a.getPrecio()>=codMayor3);
codMayor3 = a.getPrecio();
}
for (AtuendosParteAbajo a : ALParteAbajoOrdPeso) {
assertTrue(a.getPeso()>=codMayor4);
codMayor4 = a.getPeso();
}

}

@Test
public void testInsertarAtuendoAbajoTipoyGenero() {
ArrayList<AtuendosParteAbajo> ALAtuendoAbajoTipo = BaseDeDatos.getAtuendosParteAbajoPorTipo("DEPORTE");
for (AtuendosParteAbajo a : ALAtuendoAbajoTipo) {
assertEquals(TipoPantalon.DEPORTE, a.getTipo());
}
ArrayList<AtuendosParteAbajo> ALAtuendoAbajoGenero = BaseDeDatos.getAtuendosParteAbajoPorGenero("Hombre");
for (AtuendosParteAbajo a : ALAtuendoAbajoGenero) {
assertEquals("Hombre", a.getGenero());
}
}

@Test
public void testInsertarAtuendoAbajoTipoyOrdenado() {
ArrayList<AtuendosParteAbajo> ALAtuendoAbajoTipoOrd =BaseDeDatos.getAtuendosParteAbajoPorTipoYOrdenado("precio", "CAMPANA");
int codMayor = 0;
for (AtuendosParteAbajo a : ALAtuendoAbajoTipoOrd) {
assertTrue(a.getPrecio()>=codMayor);
codMayor = a.getPrecio();
assertEquals(TipoPantalon.CAMPANA, a.getTipo());
}

}

@Test
public void testInsertarAtuendoArriba() {
ArrayList<AtuendosParteArriba> ALParteArriba1 = BaseDeDatos.getAtuendosParteArriba();
BaseDeDatos.crearAtuendoParteArriba(new AtuendosParteArriba(5, "camiseta", 80, MarcasProductos.NIKE, "Hombre", 250, "negro", "seda", false, 1, "Sudadera Manga Larga", TallaParteArribaYAbajo.M));
BaseDeDatos.crearAtuendoParteArriba(new AtuendosParteArriba(6, "camiseta", 50, MarcasProductos.CARHARTT, "Mujer", 200, "blanco", "seda", true, 2, "Chaqueta", TallaParteArribaYAbajo.XS));
ArrayList<AtuendosParteArriba> ALParteArriba2 = BaseDeDatos.getAtuendosParteArriba();
// dos productos a�adidos
assertTrue(ALParteArriba1.size() +2 == ALParteArriba2.size());
}



@Test
public void testInsertarAtuendoArribaOrdenado() {
ArrayList<AtuendosParteArriba> ALParteArribaOrdId = BaseDeDatos.getAtuendosParteArribaOrdenado("id");
ArrayList<AtuendosParteArriba> ALParteArribaOrdCantidad = BaseDeDatos.getAtuendosParteArribaOrdenado("cantidad");
ArrayList<AtuendosParteArriba> ALParteArribaOrdPrecio = BaseDeDatos.getAtuendosParteArribaOrdenado("precio");
ArrayList<AtuendosParteArriba> ALParteArribaOrdPeso = BaseDeDatos.getAtuendosParteArribaOrdenado("peso");
int codMayor1 = 0;
int codMayor2 = 0;
int codMayor3 = 0;
int codMayor4 = 0;
for (AtuendosParteArriba a : ALParteArribaOrdId) {
assertTrue(a.getId()>=codMayor1);
codMayor1 = a.getId();
}
for (AtuendosParteArriba a : ALParteArribaOrdCantidad) {
assertTrue(a.getCantidad()>=codMayor2);
codMayor2 = a.getCantidad();
}
for (AtuendosParteArriba a : ALParteArribaOrdPrecio) {
assertTrue(a.getPrecio()>=codMayor3);
codMayor3 = a.getPrecio();
}
for (AtuendosParteArriba a : ALParteArribaOrdPeso) {
assertTrue(a.getPeso()>=codMayor4);
codMayor4 = a.getPeso();
}

}


@Test
public void testInsertarAtuendoArribaTipoyGenero() {
ArrayList<AtuendosParteArriba> ALAtuendoArribaTipo = BaseDeDatos.getAtuendosParteArribaPorTipo("Chaqueta");
for (AtuendosParteArriba a : ALAtuendoArribaTipo) {
assertEquals("Chaqueta", a.getTipoAtuendo());
}
ArrayList<AtuendosParteArriba> ALAtuendoArribaGenero = BaseDeDatos.getAtuendosParteArribaPorGenero("Mujer");
for (AtuendosParteArriba a : ALAtuendoArribaGenero) {
assertEquals("Mujer", a.getGenero());
}
}

@Test
public void testInsertarAtuendoArribaTipoyOrdenado() {
ArrayList<AtuendosParteArriba> ALAtuendoArribaTipoOrd =BaseDeDatos.getAtuendosParteArribaPorTipoYOrdenado("peso", "sudadera");
int codMayor = 0;
for (AtuendosParteArriba a : ALAtuendoArribaTipoOrd) {
assertTrue(a.getPeso()>=codMayor);
codMayor = a.getPeso();
assertEquals("sudadera", a.getTipoAtuendo());
}

}


@Test
public void testInsertarAtuendoZapatilla() {
ArrayList<AtuendoZapatilla> ALZapatillas1 = BaseDeDatos.getZapatillas();
BaseDeDatos.crearAtuendoZapatilla(new AtuendoZapatilla(7, "zapatilla", 100, MarcasProductos.DC_SHOES, "Hombre", 800, "rojo", "seda", false, 1, "44", "negro", TipoZapatilla.DEPORTE));
ArrayList<AtuendoZapatilla> ALZapatillas2 = BaseDeDatos.getZapatillas();
// una zapatilla a�adida
assertTrue(ALZapatillas1.size() +1 == ALZapatillas2.size());
}

@Test
public void testInsertarAtuendoZapatillasOrdenado() {
ArrayList<AtuendoZapatilla> ALZapatillasOrdId = BaseDeDatos.getZapatillasOrdenado("id");
ArrayList<AtuendoZapatilla> ALZapatillasOrdCantidad = BaseDeDatos.getZapatillasOrdenado("cantidad");
ArrayList<AtuendoZapatilla> ALZapatillasOrdPrecio = BaseDeDatos.getZapatillasOrdenado("precio");
ArrayList<AtuendoZapatilla> ALZapatillasOrdPeso = BaseDeDatos.getZapatillasOrdenado("peso");
int codMayor1 = 0;
int codMayor2 = 0;
int codMayor3 = 0;
int codMayor4 = 0;
for (AtuendoZapatilla a : ALZapatillasOrdId) {
assertTrue(a.getId()>=codMayor1);
codMayor1 = a.getId();
}
for (AtuendoZapatilla a : ALZapatillasOrdCantidad) {
assertTrue(a.getCantidad()>=codMayor2);
codMayor2 = a.getCantidad();
}
for (AtuendoZapatilla a : ALZapatillasOrdPrecio) {
assertTrue(a.getPrecio()>=codMayor3);
codMayor3 = a.getPrecio();
}
for (AtuendoZapatilla a : ALZapatillasOrdPeso) {
assertTrue(a.getPeso()>=codMayor4);
codMayor4 = a.getPeso();
}

}

@Test
public void testInsertarZapatillasTipoyGenero() {
ArrayList<AtuendoZapatilla> ALZapatillasGenero = BaseDeDatos.getZapatillasPorGenero("Unisex");
for (AtuendoZapatilla a : ALZapatillasGenero) {
assertEquals("Unisex", a.getGenero());
}
ArrayList<AtuendoZapatilla> ALZapatillasTipo = BaseDeDatos.getZapatillasPorTipo("STREETSPORT");
for (AtuendoZapatilla a : ALZapatillasTipo) {
assertEquals(TipoZapatilla.STREETSPORT, a.getTipo());
}
}

@Test
public void testInsertarZapatillasTipoyOrdenado() {
ArrayList<AtuendoZapatilla> ALZapatillasPorTipoYOrdenados = BaseDeDatos.getZapatillasPorTipoYOrdenados("id", "TACONES");
int codMayor = 0;
for (AtuendoZapatilla a : ALZapatillasPorTipoYOrdenados) {
assertTrue(a.getId()>=codMayor);
codMayor = a.getId();
assertEquals(TipoZapatilla.TACONES, a.getTipo());
}

}


@Test
public void testBorrarProductoParteAbajo() {
ArrayList<AtuendosParteAbajo> ListAbajoAntes =BaseDeDatos.getAtuendosParteAbajo();
assertTrue(ListAbajoAntes.size() == 4);
// tiene 4 productos antes de eliminar un producto
BaseDeDatos.BorrarProductoParteAbajo(2);
// elimino el producto de id = 2, que estaba colocado en el index 2
ArrayList<AtuendosParteAbajo> ListAbajoDespues =BaseDeDatos.getAtuendosParteAbajo();
// compruebo que despu�s de borrarlo la nueva lista no contiene el producto con asserts diferentes
assertFalse(ListAbajoDespues.contains(ListAbajoAntes.get(2)));
assertNotEquals(ListAbajoAntes.size(), ListAbajoDespues.size());

}

@Test
public void testBorrarProductoParteArriba() {
ArrayList<AtuendosParteArriba> ListArribaAntes = BaseDeDatos.getAtuendosParteArriba();
assertTrue(ListArribaAntes.size() == 4);
BaseDeDatos.BorrarProductoParteArriba(3);
ArrayList<AtuendosParteArriba> ListArribaDespues = BaseDeDatos.getAtuendosParteArriba();
assertFalse(ListArribaDespues.contains(ListArribaAntes.get(3)));
assertNotEquals(ListArribaAntes.size(), ListArribaDespues.size());

}

@Test
public void testBorrarProductoZapatilla() {
ArrayList<AtuendoZapatilla> ListZapatillas1 = BaseDeDatos.getZapatillas();
assertTrue(ListZapatillas1.size() == 6);
BaseDeDatos.BorrarProductoZapatilla(3);
BaseDeDatos.BorrarProductoZapatilla(4);
ArrayList<AtuendoZapatilla> ListZapatillas2 = BaseDeDatos.getZapatillas();
assertFalse(ListZapatillas2.contains(ListZapatillas1.get(3)) && ListZapatillas2.contains(ListZapatillas1.get(4)));
assertEquals(ListZapatillas1.size(), 6);
assertEquals(ListZapatillas2.size(), 4);

}

// MODIFICAR
public void testModificarAtuendoParteAbajo() {
AtuendosParteAbajo pantalon1 = new AtuendosParteAbajo(6, "pantalon pirata", 50, MarcasProductos.ELLESE, "Hombre", 420, "azul", "seda", false, 3, TipoPantalon.NORMAL, TallaParteArribaYAbajo.L);
BaseDeDatos.crearAtuendoParteAbajo(pantalon1);
BaseDeDatos.modificarAtuendoParteAbajo(pantalon1);


}

@Test
public void testRestarParteAbajo() {
ArrayList<AtuendosParteAbajo> ListAbajoAntes = BaseDeDatos.getAtuendosParteAbajo();
Double total = 0.00;
        for (AtuendosParteAbajo a : ListAbajoAntes) {
           total += a.getCantidad();
        }
        assertTrue(total == 4000);
       
BaseDeDatos.RestarCantidadDeProductosParteAbajo(1, 500);
BaseDeDatos.RestarCantidadDeProductosParteAbajo(3, 200);
BaseDeDatos.RestarCantidadDeProductosParteAbajo(4, 300);

ArrayList<AtuendosParteAbajo> ListAbajoDespues = BaseDeDatos.getAtuendosParteAbajo();
Double total2 = 0.00;
        for (AtuendosParteAbajo a : ListAbajoDespues) {
           total2 += a.getCantidad();
        }
       
        assertTrue(total2 == 3000);

// 4000 - 1000 = 3000
       
}

@Test
public void testRestarParteArriba() {
ArrayList<AtuendosParteArriba> ListAbajoAntes = BaseDeDatos.getAtuendosParteArriba();
Double total = 0.00;
        for (AtuendosParteArriba a : ListAbajoAntes) {
           total += a.getCantidad();
        }
        assertTrue(total == 4000);
       
BaseDeDatos.RestarCantidadDeProductosParteArriba(2, 1500);

ArrayList<AtuendosParteArriba> ListAbajoDespues = BaseDeDatos.getAtuendosParteArriba();
Double total2 = 0.00;
        for (AtuendosParteArriba a : ListAbajoDespues) {
           total2 += a.getCantidad();
        }
       
        assertTrue(total2 == 2500);

// 4000 - 1500 = 2500
       
}

@Test
public void testRestarZapatilla() {
ArrayList<AtuendoZapatilla> ListZapatillas = BaseDeDatos.getZapatillas();
Double total = 0.00;
        for (AtuendoZapatilla a : ListZapatillas) {
        total += a.getCantidad();
}
        assertTrue(total == 6000);
       
BaseDeDatos.RestarCantidadDeZapatillas(1, 1500);
BaseDeDatos.RestarCantidadDeZapatillas(2, 1500);
BaseDeDatos.RestarCantidadDeZapatillas(3, 1500);
BaseDeDatos.RestarCantidadDeZapatillas(4, 1500);

ArrayList<AtuendoZapatilla> ListZapatillas2 = BaseDeDatos.getZapatillas();
Double total2 = 0.00;
        for (AtuendoZapatilla a : ListZapatillas2) {
           total2 += a.getCantidad();
        }
        assertTrue(total2 == 0);

// 6000 - 6000 = 0
       
}






}