package ventanas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import BaseDeDatos.BaseDeDatos;

public class VentanaMiniCarrito extends JFrame{
	private JFrame frmVentanaMiniCarrito;
	private JLabel atuendos;
	private JLabel totalCoste;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaMiniCarrito window = new VentanaMiniCarrito();
					window.frmVentanaMiniCarrito.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public VentanaMiniCarrito() {
		//BaseDeDatos.inicioConexion("BaseDeDatos1.db");
		initialize();
		
	}
	
	
	private void initialize() {
		
		frmVentanaMiniCarrito = new JFrame();
		frmVentanaMiniCarrito.setTitle("Carrito");
		frmVentanaMiniCarrito.getContentPane().setBackground(new Color(0xa8ccba));
		//this.setSize(600, 300);
		frmVentanaMiniCarrito.setBounds(50, 50, 150, 110);
		frmVentanaMiniCarrito.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frmVentanaMiniCarrito.getContentPane().setLayout(null);
		
		
		int carrito = BaseDeDatos.getLengthCarrito();
		
		atuendos = new JLabel(carrito + " atuendos");
		atuendos.setBounds(62, 149, 79, 13);
		
	}

}
