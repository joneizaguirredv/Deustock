package enumeraciones;

public enum TipoZapatilla {
	DEPORTE, STREETSPORT, BOTAS, TACONES, BAILARINAS;

}