package JUnit;

import static org.junit.Assert.*;

import java.sql.Connection;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import BaseDeDatos.BaseDeDatos;
import clases.Administrador;
import clases.AtuendoZapatilla;
import clases.AtuendosParteAbajo;
import clases.AtuendosParteArriba;
import clases.Carrito;
import clases.Cliente;
import clases.Pedido;
import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;
import enumeraciones.TipoPantalon;
import enumeraciones.TipoZapatilla;
import excepciones.MiExcepcionExplicita;


//Junits de todos los métodos de la Base de Datos con varios ejemplos

public class JUnitBSD {
	private boolean conexion;

	@Before
	public void before() throws Exception {
		conexion = BaseDeDatos.inicioConexion("BaseDeDatos1.db");
	}

	@After
	public void after() throws Exception {
		BaseDeDatos.cerrarConexion();
	}


	@Test
	public void testInsertarAtuendoAbajo() {
		ArrayList<AtuendosParteAbajo> ALParteAbajo1 = BaseDeDatos.getAtuendosParteAbajo();
		BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(5, "pantalon alto", 75, MarcasProductos.ZARA, "Mujer", 400, "blanco", "lana", true, 1, TipoPantalon.CAMPANA, TallaParteArribaYAbajo.S));
		BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(6, "pantalon pirata", 50, MarcasProductos.ELLESE, "Hombre", 420, "azul", "seda", false, 3, TipoPantalon.NORMAL, TallaParteArribaYAbajo.L));
		BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(7, "pantalon corto", 55, MarcasProductos.LEVIS, "Unisex", 515, "azul", "lana", true, 2, TipoPantalon.PITILLO, TallaParteArribaYAbajo.XLL));
		ArrayList<AtuendosParteAbajo> ALParteAbajo2 = BaseDeDatos.getAtuendosParteAbajo();
		// tres productos añadidos
		assertTrue(ALParteAbajo1.size() +3 == ALParteAbajo2.size());

	}

	@Test
	public void testInsertarAtuendoAbajoOrdenado() {
		ArrayList<AtuendosParteAbajo> ALParteAbajoOrdId = BaseDeDatos.getAtuendosParteAbajoOrdenado("id");
		ArrayList<AtuendosParteAbajo> ALParteAbajoOrdCantidad = BaseDeDatos.getAtuendosParteAbajoOrdenado("cantidad");
		ArrayList<AtuendosParteAbajo> ALParteAbajoOrdPrecio = BaseDeDatos.getAtuendosParteAbajoOrdenado("precio");
		ArrayList<AtuendosParteAbajo> ALParteAbajoOrdPeso = BaseDeDatos.getAtuendosParteAbajoOrdenado("peso");
		int codMayor1 = 0;
		int codMayor2 = 0;
		int codMayor3 = 0;
		int codMayor4 = 0;
		for (AtuendosParteAbajo a : ALParteAbajoOrdId) {
			assertTrue(a.getId()>=codMayor1);
			codMayor1 = a.getId();
		}
		for (AtuendosParteAbajo a : ALParteAbajoOrdCantidad) {
			assertTrue(a.getCantidad()>=codMayor2);
			codMayor2 = a.getCantidad();
		}
		for (AtuendosParteAbajo a : ALParteAbajoOrdPrecio) {
			assertTrue(a.getPrecio()>=codMayor3);
			codMayor3 = a.getPrecio();
		}
		for (AtuendosParteAbajo a : ALParteAbajoOrdPeso) {
			assertTrue(a.getPeso()>=codMayor4);
			codMayor4 = a.getPeso();
		}

	}

	@Test
	public void testInsertarAtuendoAbajoTipoyGenero() {
		ArrayList<AtuendosParteAbajo> ALAtuendoAbajoTipo = BaseDeDatos.getAtuendosParteAbajoPorTipo("DEPORTE");
		for (AtuendosParteAbajo a : ALAtuendoAbajoTipo) {
			assertEquals(TipoPantalon.DEPORTE, a.getTipo());
		}
		ArrayList<AtuendosParteAbajo> ALAtuendoAbajoGenero = BaseDeDatos.getAtuendosParteAbajoPorGenero("Hombre");
		for (AtuendosParteAbajo a : ALAtuendoAbajoGenero) {
			assertEquals("Hombre", a.getGenero());
		}
	}

	@Test
	public void testInsertarAtuendoAbajoTipoyOrdenado() {
		ArrayList<AtuendosParteAbajo> ALAtuendoAbajoTipoOrd =BaseDeDatos.getAtuendosParteAbajoPorTipoYOrdenado("precio", "CAMPANA");
		int codMayor = 0;
		for (AtuendosParteAbajo a : ALAtuendoAbajoTipoOrd) {
			assertTrue(a.getPrecio()>=codMayor);
			codMayor = a.getPrecio();
			assertEquals(TipoPantalon.CAMPANA, a.getTipo());
		}

	}

	@Test
	public void testInsertarAtuendoArriba() {
		ArrayList<AtuendosParteArriba> ALParteArriba1 = BaseDeDatos.getAtuendosParteArriba();
		BaseDeDatos.crearAtuendoParteArriba(new AtuendosParteArriba(5, "camiseta", 80, MarcasProductos.NIKE, "Hombre", 250, "negro", "seda", false, 1, "Sudadera Manga Larga", TallaParteArribaYAbajo.M));
		BaseDeDatos.crearAtuendoParteArriba(new AtuendosParteArriba(6, "camiseta", 50, MarcasProductos.CARHARTT, "Mujer", 200, "blanco", "seda", true, 2, "Chaqueta", TallaParteArribaYAbajo.XS));
		ArrayList<AtuendosParteArriba> ALParteArriba2 = BaseDeDatos.getAtuendosParteArriba();
		// dos productos añadidos
		assertTrue(ALParteArriba1.size() +2 == ALParteArriba2.size());
	}



	@Test
	public void testInsertarAtuendoArribaOrdenado() {
		ArrayList<AtuendosParteArriba> ALParteArribaOrdId = BaseDeDatos.getAtuendosParteArribaOrdenado("id");
		ArrayList<AtuendosParteArriba> ALParteArribaOrdCantidad = BaseDeDatos.getAtuendosParteArribaOrdenado("cantidad");
		ArrayList<AtuendosParteArriba> ALParteArribaOrdPrecio = BaseDeDatos.getAtuendosParteArribaOrdenado("precio");
		ArrayList<AtuendosParteArriba> ALParteArribaOrdPeso = BaseDeDatos.getAtuendosParteArribaOrdenado("peso");
		int codMayor1 = 0;
		int codMayor2 = 0;
		int codMayor3 = 0;
		int codMayor4 = 0;
		for (AtuendosParteArriba a : ALParteArribaOrdId) {
			assertTrue(a.getId()>=codMayor1);
			codMayor1 = a.getId();
		}
		for (AtuendosParteArriba a : ALParteArribaOrdCantidad) {
			assertTrue(a.getCantidad()>=codMayor2);
			codMayor2 = a.getCantidad();
		}
		for (AtuendosParteArriba a : ALParteArribaOrdPrecio) {
			assertTrue(a.getPrecio()>=codMayor3);
			codMayor3 = a.getPrecio();
		}
		for (AtuendosParteArriba a : ALParteArribaOrdPeso) {
			assertTrue(a.getPeso()>=codMayor4);
			codMayor4 = a.getPeso();
		}

	}


	@Test
	public void testInsertarAtuendoArribaTipoyGenero() {
		ArrayList<AtuendosParteArriba> ALAtuendoArribaTipo = BaseDeDatos.getAtuendosParteArribaPorTipo("Chaqueta");
		for (AtuendosParteArriba a : ALAtuendoArribaTipo) {
			assertEquals("Chaqueta", a.getTipoAtuendo());
		}
		ArrayList<AtuendosParteArriba> ALAtuendoArribaGenero = BaseDeDatos.getAtuendosParteArribaPorGenero("Mujer");
		for (AtuendosParteArriba a : ALAtuendoArribaGenero) {
			assertEquals("Mujer", a.getGenero());
		}
	}

	@Test
	public void testInsertarAtuendoArribaTipoyOrdenado() {
		ArrayList<AtuendosParteArriba> ALAtuendoArribaTipoOrd =BaseDeDatos.getAtuendosParteArribaPorTipoYOrdenado("peso", "sudadera");
		int codMayor = 0;
		for (AtuendosParteArriba a : ALAtuendoArribaTipoOrd) {
			assertTrue(a.getPeso()>=codMayor);
			codMayor = a.getPeso();
			assertEquals("sudadera", a.getTipoAtuendo());
		}

	}


	@Test
	public void testInsertarAtuendoZapatilla() {
		ArrayList<AtuendoZapatilla> ALZapatillas1 = BaseDeDatos.getZapatillas();
		BaseDeDatos.crearAtuendoZapatilla(new AtuendoZapatilla(7, "zapatilla", 100, MarcasProductos.DC_SHOES, "Hombre", 800, "rojo", "seda", false, 1, "44", "negro", TipoZapatilla.DEPORTE));
		ArrayList<AtuendoZapatilla> ALZapatillas2 = BaseDeDatos.getZapatillas();
		// una zapatilla añadida
		assertTrue(ALZapatillas1.size() +1 == ALZapatillas2.size());
	}

	@Test
	public void testInsertarAtuendoZapatillasOrdenado() {
		ArrayList<AtuendoZapatilla> ALZapatillasOrdId = BaseDeDatos.getZapatillasOrdenado("id");
		ArrayList<AtuendoZapatilla> ALZapatillasOrdCantidad = BaseDeDatos.getZapatillasOrdenado("cantidad");
		ArrayList<AtuendoZapatilla> ALZapatillasOrdPrecio = BaseDeDatos.getZapatillasOrdenado("precio");
		ArrayList<AtuendoZapatilla> ALZapatillasOrdPeso = BaseDeDatos.getZapatillasOrdenado("peso");
		int codMayor1 = 0;
		int codMayor2 = 0;
		int codMayor3 = 0;
		int codMayor4 = 0;
		for (AtuendoZapatilla a : ALZapatillasOrdId) {
			assertTrue(a.getId()>=codMayor1);
			codMayor1 = a.getId();
		}
		for (AtuendoZapatilla a : ALZapatillasOrdCantidad) {
			assertTrue(a.getCantidad()>=codMayor2);
			codMayor2 = a.getCantidad();
		}
		for (AtuendoZapatilla a : ALZapatillasOrdPrecio) {
			assertTrue(a.getPrecio()>=codMayor3);
			codMayor3 = a.getPrecio();
		}	
		for (AtuendoZapatilla a : ALZapatillasOrdPeso) {
			assertTrue(a.getPeso()>=codMayor4);
			codMayor4 = a.getPeso();
		}

	}

	@Test
	public void testInsertarAtuendoZapatillasTipoyGenero() {
		ArrayList<AtuendoZapatilla> ALZapatillasGenero = BaseDeDatos.getZapatillasPorGenero("Unisex");
		for (AtuendoZapatilla a : ALZapatillasGenero) {
			assertEquals("Unisex", a.getGenero());
		}
		ArrayList<AtuendoZapatilla> ALZapatillasTipo = BaseDeDatos.getZapatillasPorTipo("STREETSPORT");
		for (AtuendoZapatilla a : ALZapatillasTipo) {
			assertEquals(TipoZapatilla.STREETSPORT, a.getTipo());
		}
	}

	@Test
	public void testInsertarAtuendoZapatillasTipoyOrdenado() {
		ArrayList<AtuendoZapatilla> ALZapatillasPorTipoYOrdenados = BaseDeDatos.getZapatillasPorTipoYOrdenados("id", "TACONES");
		int codMayor = 0;
		for (AtuendoZapatilla a : ALZapatillasPorTipoYOrdenados) {
			assertTrue(a.getId()>=codMayor);
			codMayor = a.getId();
			assertEquals(TipoZapatilla.TACONES, a.getTipo());
		}

	}

	@Test
	public void testInsertarCarrito() {
		ArrayList<Carrito> ALCarritoAntes = BaseDeDatos.getCarrito();
		BaseDeDatos.crearCarrito(new Carrito("Favorito", 4, 100, "tipo2"));
		BaseDeDatos.crearCarrito(new Carrito("Navidades", 10, 400, "tipo1"));
		ArrayList<Carrito> ALCarritoDespues = BaseDeDatos.getCarrito();
		assertEquals(ALCarritoAntes.size()+2, ALCarritoDespues.size());

	}

	@Test
	public void testInsertarCliente() {
		try {
			ArrayList<String> ALClientesAntes = BaseDeDatos.getClientes();
			BaseDeDatos.crearCliente(new Cliente(4, "asieriturriotz@gmail.com", "Asier", "Iturriotz", "lacasito123", 688642913, 48007 ));
			ArrayList<String> ALClientesDespues = BaseDeDatos.getClientes();
			assertEquals(ALClientesAntes.size()+1, ALClientesDespues.size());
		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

/*	@Test
	public void testInsertarCompra() {
		try {
			BaseDeDatos.crearCliente(new Cliente(4, "asieriturriotz@opendeusto.es", "Asier", "Iturriotz", "lacasito123", 688642913, 48007));
			BaseDeDatos.crearCliente(new Cliente(5, "jonandergallas@opendeusto.es", "Jon Ander", "Gallastegi", "basurto1", 615668324, 48003));
			ArrayList<Pedido> ALComprasUsuarioAntes = BaseDeDatos.getComprasUsuario("asieriturriotz@opendeusto.es");
			ArrayList<Pedido> ALComprasUsuario2Antes = BaseDeDatos.getComprasUsuario("jonandergallas@opendeusto.es");
			BaseDeDatos.crearCompra(new Pedido(1, "asieriturriotz@opendeusto.es", "camiseta", 1, 80, "sudadera", 18/01/2022, 20/01/2022));
			BaseDeDatos.crearCompra(new Pedido(2, "jonandergallas@opendeusto.es", "camiseta", 2, 100, "chaqueta", 18/01/2022, 20/01/2022));
			BaseDeDatos.crearCompra(new Pedido(3, "asieriturriotz@opendeusto.es", "camiseta", 1, 60, "sudadera", 18/01/2022, 20/01/2022));
			ArrayList<Pedido> ALComprasUsuarioDespues = BaseDeDatos.getComprasUsuario("asieriturriotz@opendeusto.es");
			ArrayList<Pedido> ALComprasUsuario2Despues = BaseDeDatos.getComprasUsuario("jonandergallas@opendeusto.es");
			assertEquals(ALComprasUsuarioAntes.size()+2, ALComprasUsuarioDespues);
			assertEquals(ALComprasUsuario2Antes.size()+1, ALComprasUsuario2Despues);

		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Test
	public void testGetContraseniaCliente() {
		try {
			BaseDeDatos.crearCliente(new Cliente(4, "asieriturriotz@opendeusto.es", "Asier", "Iturriotz", "lacasito123", 688642913, 48007));
			BaseDeDatos.crearCliente(new Cliente(5, "jonandergallas@opendeusto.es", "Jon Ander", "Gallastegi", "basurto1", 615668324, 48003));
			String contraA = BaseDeDatos.getContraseniaCliente("asieriturriotz@opendeusto.es");
			String contraJ = BaseDeDatos.getContraseniaCliente("jonandergallas@opendeusto.es");
			assertEquals(contraA,"lacasito123");
			assertEquals(contraJ,"basurto1");

		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Test
	public void testGetAdministradores() {
		try {
			ArrayList<String> ALAdminsAntes = BaseDeDatos.getAdministradores();
			BaseDeDatos.crearAdministrador(new Administrador(1, "asieriturriotz@opendeusto.es", "lacasitos123", "Asier", "Iturriotz", "009888446"));
			ArrayList<String> ALAdminsDespues = BaseDeDatos.getAdministradores();
			assertEquals(ALAdminsAntes.size()+1, ALAdminsDespues.size());

		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Test
	public void testGetContraseniaAdministrador() {
		try {
			BaseDeDatos.crearAdministrador(new Administrador(1, "asieriturriotz@opendeusto.es", "lacasitos123", "Asier", "Iturriotz", "009888446"));
			BaseDeDatos.crearAdministrador(new Administrador(2, "jonandergallas@opendeusto.es", "basurto1", "Jon Ander", "Gallastegi", "021346302"));
			String contraA = BaseDeDatos.getContraseniaAdministrador("asieriturriotz@opendeusto.es");
			String contraJ = BaseDeDatos.getContraseniaAdministrador("jonandergallas@opendeusto.es");
			assertEquals(contraA,"lacasito123");
			assertEquals(contraJ,"basurto1");

		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/

	@Test
	public void testBorrarProductoParteAbajo() {
		ArrayList<AtuendosParteAbajo> ListAbajoAntes =BaseDeDatos.getAtuendosParteAbajo();
		assertTrue(ListAbajoAntes.size() == 4);
		// tiene 4 productos antes de eliminar un producto
		BaseDeDatos.BorrarProductoParteAbajo(2);
		// elimino el producto de id = 2, que estaba colocado en el index 2
		ArrayList<AtuendosParteAbajo> ListAbajoDespues =BaseDeDatos.getAtuendosParteAbajo();
		// compruebo que después de borrarlo la nueva lista no contiene el producto con asserts diferentes
		assertFalse(ListAbajoDespues.contains(ListAbajoAntes.get(2)));
		assertNotEquals(ListAbajoAntes.size(), ListAbajoDespues.size());

	}

	@Test
	public void testBorrarProductoParteArriba() {
		ArrayList<AtuendosParteArriba> ListArribaAntes = BaseDeDatos.getAtuendosParteArriba();
		assertTrue(ListArribaAntes.size() == 4);
		BaseDeDatos.BorrarProductoParteArriba(3);
		ArrayList<AtuendosParteArriba> ListArribaDespues = BaseDeDatos.getAtuendosParteArriba();
		assertFalse(ListArribaDespues.contains(ListArribaAntes.get(3)));
		assertNotEquals(ListArribaAntes.size(), ListArribaDespues.size());

	}

	@Test
	public void testBorrarProductoZapatilla() {
		ArrayList<AtuendoZapatilla> ListZapatillas1 = BaseDeDatos.getZapatillas();
		assertTrue(ListZapatillas1.size() == 6);
		BaseDeDatos.BorrarProductoZapatilla(3);
		BaseDeDatos.BorrarProductoZapatilla(4);
		ArrayList<AtuendoZapatilla> ListZapatillas2 = BaseDeDatos.getZapatillas();
		assertFalse(ListZapatillas2.contains(ListZapatillas1.get(3)) && ListZapatillas2.contains(ListZapatillas1.get(4)));
		assertEquals(ListZapatillas1.size(), 6);
		assertEquals(ListZapatillas2.size(), 4);

	}

	@Test
	public void testModificarAtuendoParteAbajo() {
		BaseDeDatos.crearAtuendoParteAbajo(new AtuendosParteAbajo(5, "pantalon pirata", 50, MarcasProductos.ELLESE, "Hombre", 420, "azul", "seda", false, 5, TipoPantalon.NORMAL, TallaParteArribaYAbajo.L));
		ArrayList<AtuendosParteAbajo> ALAbajo = BaseDeDatos.getAtuendosParteAbajo();
		AtuendosParteAbajo pantalon1 = ALAbajo.get(4);
		assertTrue(pantalon1.getPrecio() == 50 && pantalon1.getCantidad() == 5);
		pantalon1.setPrecio(45);
		pantalon1.setCantidad(pantalon1.getCantidad()-1);
		BaseDeDatos.modificarAtuendoParteAbajo(pantalon1);
		ArrayList<AtuendosParteAbajo> ALAbajo2 = BaseDeDatos.getAtuendosParteAbajo();
		AtuendosParteAbajo pantalon2 = ALAbajo2.get(4);
		assertTrue(pantalon2.getPrecio() == 45 && pantalon2.getCantidad() == 4);

		// crear objeto
		// cambiar el precio y la cantidad
		// llama a la funcion
		// comprobar que el nuevo precio y cantidad es ese en la base de datos
	}

	@Test
	public void testModificarAtuendoParteArriba() {
		BaseDeDatos.crearAtuendoParteArriba(new AtuendosParteArriba(5, "camiseta", 50, MarcasProductos.CARHARTT, "Mujer", 200, "blanco", "seda", true, 2, "Chaqueta", TallaParteArribaYAbajo.XS));
		ArrayList<AtuendosParteArriba> ALArriba = BaseDeDatos.getAtuendosParteArriba();
		AtuendosParteArriba camiseta1 = ALArriba.get(4);
		assertTrue(camiseta1.getMarca() == MarcasProductos.CARHARTT);
		camiseta1.setMarca(MarcasProductos.ADIDAS);
		BaseDeDatos.modificarAtuendoParteArriba(camiseta1);
		ArrayList<AtuendosParteArriba> ALArriba2 = BaseDeDatos.getAtuendosParteArriba();
		AtuendosParteArriba camiseta2 = ALArriba2.get(4);
		assertTrue(camiseta2.getMarca() == MarcasProductos.ADIDAS);
	}

	@Test
	public void testModificarZapatillas(){
		ArrayList<AtuendoZapatilla> ALZapatillas = BaseDeDatos.getZapatillas();
		AtuendoZapatilla zapatilla1 = ALZapatillas.get(0); // 1 zapatilla 15 ELEMENT Unisex 123 Azul Seda 1 1000 42 Azul DEPORTE
		AtuendoZapatilla zapatilla2  = ALZapatillas.get(4);// 5 zapatilla 30 ELEMENT Unisex 123 Azul Seda 1 1000 42 Azul BOTAS
		assertTrue(zapatilla1.getPeso() == 123);
		assertTrue(zapatilla2.getId() == 5);
		zapatilla1.setPeso(123);
		zapatilla2.setId(6);
		BaseDeDatos.modificarZapatillas(zapatilla1);
		BaseDeDatos.modificarZapatillas(zapatilla2);
		ArrayList<AtuendoZapatilla> ALZapatillas2 = BaseDeDatos.getZapatillas();
		AtuendoZapatilla zapatilla3 = ALZapatillas.get(0);
		AtuendoZapatilla zapatilla4 = ALZapatillas.get(4);
		assertTrue(zapatilla3.getPeso() == 123);
		assertTrue(zapatilla4.getId() == 6);

}

	@Test
	public void testRestarParteAbajo() {
		ArrayList<AtuendosParteAbajo> ListAbajoAntes = BaseDeDatos.getAtuendosParteAbajo();
		Double total = 0.00;
        for (AtuendosParteAbajo a : ListAbajoAntes) {
           total += a.getCantidad();
        }
        assertTrue(total == 4000);
       
        BaseDeDatos.RestarCantidadDeProductosParteAbajo(1, 500);
        BaseDeDatos.RestarCantidadDeProductosParteAbajo(3, 200);
        BaseDeDatos.RestarCantidadDeProductosParteAbajo(4, 300);

        ArrayList<AtuendosParteAbajo> ListAbajoDespues = BaseDeDatos.getAtuendosParteAbajo();
        Double total2 = 0.00;
        for (AtuendosParteAbajo a : ListAbajoDespues) {
           total2 += a.getCantidad();
        }
       
        assertTrue(total2 == 3000);

        // 4000 - 1000 = 3000
       
	}

	@Test
	public void testRestarParteArriba() {
		ArrayList<AtuendosParteArriba> ListAbajoAntes = BaseDeDatos.getAtuendosParteArriba();
		Double total = 0.00;
        for (AtuendosParteArriba a : ListAbajoAntes) {
           total += a.getCantidad();
        }
        assertTrue(total == 4000);
       
        BaseDeDatos.RestarCantidadDeProductosParteArriba(2, 1500);

        ArrayList<AtuendosParteArriba> ListAbajoDespues = BaseDeDatos.getAtuendosParteArriba();
        Double total2 = 0.00;
        for (AtuendosParteArriba a : ListAbajoDespues) {
           total2 += a.getCantidad();
        }
       
        assertTrue(total2 == 2500);

        // 4000 - 1500 = 2500
       
	}

	@Test
	public void testRestarZapatilla() {
		ArrayList<AtuendoZapatilla> ListZapatillas = BaseDeDatos.getZapatillas();
		Double total = 0.00;
        for (AtuendoZapatilla a : ListZapatillas) {
        	total += a.getCantidad();
        }
        assertTrue(total == 6000);
       
        BaseDeDatos.RestarCantidadDeZapatillas(1, 1500);
        BaseDeDatos.RestarCantidadDeZapatillas(2, 1500);
        BaseDeDatos.RestarCantidadDeZapatillas(3, 1500);
        BaseDeDatos.RestarCantidadDeZapatillas(4, 1500);

        ArrayList<AtuendoZapatilla> ListZapatillas2 = BaseDeDatos.getZapatillas();
        Double total2 = 0.00;
        for (AtuendoZapatilla a : ListZapatillas2) {
           total2 += a.getCantidad();
        }
        assertTrue(total2 == 0);

        // 6000 - 6000 = 0
       
	}
	@Test
	public void testEliminarUsuarioBSD() {
		try {
			BaseDeDatos.crearCliente(new Cliente(4, "asieriturriotz@gmail.com", "Asier", "Iturriotz", "lacasito123", 688642913, 48007 ));
			ArrayList<String> AlClientesAntes = BaseDeDatos.getClientes();
			assertTrue(AlClientesAntes.size() == 1);
			BaseDeDatos.EliminarUsuarioDeBaseDeDatos();
			ArrayList<String> AlClientesDespues = BaseDeDatos.getClientes();
			assertTrue(AlClientesDespues.size() == 0);

		} catch (MiExcepcionExplicita e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testEliminarCarrito() {
		Carrito c1 = new Carrito("Favorito", 4, 100, "tipo2");
		Carrito c2 = new Carrito("Navidades", 10, 400, "tipo1");
		BaseDeDatos.crearCarrito(c1);
		BaseDeDatos.crearCarrito(c2);
		ArrayList<Carrito> CarritoAntes = BaseDeDatos.getCarrito();
		assertTrue(CarritoAntes.size() == 2);
		BaseDeDatos.EliminarCarrito();
		ArrayList<Carrito> CarritoDespues = BaseDeDatos.getCarrito();
		assertTrue(CarritoDespues.size() == 0);

	}

}