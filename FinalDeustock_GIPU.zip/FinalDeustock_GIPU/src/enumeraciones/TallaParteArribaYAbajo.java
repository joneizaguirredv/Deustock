package enumeraciones;

public enum TallaParteArribaYAbajo {
	XS, S, M, L, XL, XLL;

}
