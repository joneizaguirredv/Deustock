package enumeraciones;

public enum TipoPantalon {
	PITILLO, CAMPANA, NORMAL, CORTO, DEPORTE;

}