package clases;

public class Carrito {
	
	private String Nombre;
	private int Cantidad;
	private int Precio;
	private String Tipo;
	
	
	public Carrito(String nombre, int cantidad, int precio, String tipo) {
		super();
		Nombre = nombre;
		Cantidad = cantidad;
		Precio = precio;
		Tipo = tipo;
	}
	
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public int getCantidad() {
		return Cantidad;
	}
	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}
	public int getPrecio() {
		return Precio;
	}
	public void setPrecio(int precio) {
		Precio = precio;
	}
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
	
	
	
	
	
	
}
