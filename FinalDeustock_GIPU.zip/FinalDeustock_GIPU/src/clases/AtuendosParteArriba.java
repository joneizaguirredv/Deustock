package clases;

import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;

public class AtuendosParteArriba extends Producto {
	private TallaParteArribaYAbajo TallaArriba;
	private String TipoAtuendo;

	public AtuendosParteArriba(int id, String nombre, int precio, MarcasProductos marca, String genero, int peso, String color, String material,
			Boolean estampado, int cantidad, String tipoAtuendo, TallaParteArribaYAbajo tallaArriba) {
		super(id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad);
		TallaArriba = tallaArriba;
		TipoAtuendo = tipoAtuendo;
	}
	
	
	

	public TallaParteArribaYAbajo getTallaArriba() {
		return TallaArriba;
	}




	public void setTallaArriba(TallaParteArribaYAbajo tallaArriba) {
		TallaArriba = tallaArriba;
	}




	public String getTipoAtuendo() {
		return TipoAtuendo;
	}




	public void setTipoAtuendo(String tipoAtuendo) {
		TipoAtuendo = tipoAtuendo;
	}




	@Override
	public String toString() {
		return "AtuendosParteArriba [toString()=" + super.toString() + "TallaArriba=" + TallaArriba + "]";
	}

}