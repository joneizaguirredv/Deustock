package interfaces;

public interface I {
	boolean puedeEditar();
}
