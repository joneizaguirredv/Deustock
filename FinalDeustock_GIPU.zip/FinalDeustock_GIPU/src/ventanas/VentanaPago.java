package ventanas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import BaseDeDatos.BaseDeDatos;
import clases.Carrito;
import clases.Cliente;
import clases.Pago;
import clases.Pedido;
import excepciones.MiExcepcionExplicita;

import java.awt.EventQueue;
import ventanas.VentanaUsuario;

import java.util.concurrent.ThreadLocalRandom;

public class VentanaPago extends JFrame {
	private JLabel visa;
	private JLabel kutxa;
	private JLabel candado;
	private JFrame frmVentanaPago;
	private JLabel caducidadL;
	private JLabel ejemploL;
	private JLabel cvvL;
	private JLabel cuentaBancariaL;
	private JTextField cuentaBancaria;
	private JTextField caducidad;
	private JTextField cvv;
	private JButton btnPagar;
	//private JPanel pNorte;
	//private JPanel pSur;
	//private JPanel pCentro;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPago window = new VentanaPago();
					window.frmVentanaPago.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public VentanaPago() {
		//BaseDeDatos.inicioConexion("BaseDeDatos1.db");
		initialize();
			
	}


	private void initialize() {
		
		
		//Ventana de pago
		
		frmVentanaPago = new JFrame();
		frmVentanaPago.setTitle("Pago");
		frmVentanaPago.getContentPane().setBackground(new Color(0xa8ccba));
		//this.setSize(600, 300);
		frmVentanaPago.setBounds(200, 200, 500, 350);
		frmVentanaPago.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frmVentanaPago.getContentPane().setLayout(null);
		
		//Imagen de visa
		
		visa = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/visa1.png"));
			Image tama�o = img.getScaledInstance(150, 45, Image.SCALE_SMOOTH);
			
			visa.setIcon(new ImageIcon(tama�o));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		visa.setBounds(10, 0, 200, 95);
		frmVentanaPago.getContentPane().add(visa);

		
		//Imagen kutxa
		
		kutxa = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/kutxabank.png"));
			Image tama�o = img.getScaledInstance(120, 85, Image.SCALE_SMOOTH);
			
			kutxa.setIcon(new ImageIcon(tama�o));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		kutxa.setBounds(300, 0, 200, 85);
		frmVentanaPago.getContentPane().add(kutxa);
		
		
		//Imagen candado
		
		candado = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/candado.png"));
			Image tama�o = img.getScaledInstance(85, 85, Image.SCALE_SMOOTH);
			
			candado.setIcon(new ImageIcon(tama�o));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		candado.setBounds(320, 0, 200, 340);
		frmVentanaPago.getContentPane().add(candado);
		
		
		//JLabels al lado del cuadro de texto
		
		cuentaBancariaL = new JLabel("Cuenta bancaria:");
		cuentaBancariaL.setBounds(29, 103, 110, 13);
		frmVentanaPago.getContentPane().add(cuentaBancariaL);
		caducidadL = new JLabel("Caducidad:");
		caducidadL.setBounds(62, 149, 79, 13);
		frmVentanaPago.getContentPane().add(caducidadL);
		ejemploL = new JLabel("(ej:mm.aa)");
		ejemploL.setBounds(65, 163, 79, 13);
		frmVentanaPago.getContentPane().add(ejemploL);
		cvvL = new JLabel("CVV:");
		cvvL.setBounds(98, 195, 113, 13);
		frmVentanaPago.getContentPane().add(cvvL);
		
		
		//JTextFields cuadros de texto
		
		cuentaBancaria = new JTextField();
		cuentaBancaria.setBackground(Color.WHITE);
		cuentaBancaria.setBounds(135, 100, 119, 19);
		frmVentanaPago.getContentPane().add(cuentaBancaria);
		cuentaBancaria.setColumns(10);
		
		caducidad = new JTextField();
		caducidad.setBackground(Color.WHITE);
		caducidad.setBounds(135, 146, 119, 19);
		frmVentanaPago.getContentPane().add(caducidad);
		
		cvv = new JTextField();
		cvv.setBackground(Color.WHITE);
		cvv.setBounds(135, 192, 119, 19);
		frmVentanaPago.getContentPane().add(cvv);
		
		
		//pulsador realizar pago
		
		btnPagar = new JButton("Realizar pago");
		btnPagar.setForeground(Color.WHITE);
		btnPagar.setBackground(SystemColor.desktop);
		btnPagar.setBounds(135, 238, 119, 30);
		btnPagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chequearPago();
				
			}
		});
		
		frmVentanaPago.getContentPane().add(btnPagar);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 80, 466, 34);
		frmVentanaPago.getContentPane().add(separator);
		
		frmVentanaPago.setVisible(true);
		
	}
		
		//Generar numeros de pedido aleatorios
		
		int numeroPedido = ThreadLocalRandom.current().nextInt(1000000, 9999999 + 1);
		
		//Metodos para chequear
		
		private void chequearPago() {
			ArrayList<String> listaAdministradores = BaseDeDatos.getAdministradores();
			ArrayList<String> listaUsuarios = BaseDeDatos.getClientes();
			ArrayList<Pago> listaPagos = BaseDeDatos.getPagos();
			System.out.println(listaAdministradores);
			
			String cuentaT = cuentaBancaria.getText();
			String caducidadT = caducidad.getText();
			String cvvT = cvv.getText();
			String correoT = BaseDeDatos.cargarCorreoDeUnCliente();
			int idT = BaseDeDatos.cargarIdDeUnCliente();
			String nombreT = BaseDeDatos.cargarNombreDeUnCliente(correoT);
			String apellidoT = BaseDeDatos.cargarApellidoDeUnCliente(correoT);
			String contrase�aT = BaseDeDatos.cargarContrase�aDeUnCliente(correoT);
			
			if(cuentaT.equals("") || caducidadT.equals("") || cvvT.equals("")) {
				JOptionPane.showMessageDialog(null, "Rellena todos los campos");
				
			}else if(cuentaT.length() != 16) {
				JOptionPane.showMessageDialog(null, "La cuenta bancaria introducida no existe");
			
			}else if(caducidadT.length() > 5){
				JOptionPane.showMessageDialog(null, "La fecha de caducidad introducida no es correcta");
			
			}else if(cvvT.length() != 3) {
				JOptionPane.showMessageDialog(null, "El CVV introducido no es correcto");
			}else {
				
				try {
					BaseDeDatos.crearPago(new Pago(1, correoT, nombreT, apellidoT, contrase�aT, cuentaT, caducidadT, cvvT));
				} catch (MiExcepcionExplicita e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Su compra se ha realizado correctamente.\n"
						+ "Su numero de pedido es:\n" + numeroPedido);
				System.exit(0);
			}
		}
		
		
		
		

	}
	
	
	
	
	
	
	

