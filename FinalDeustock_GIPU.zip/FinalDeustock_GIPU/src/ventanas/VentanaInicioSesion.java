package ventanas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.JToggleButton;
import javax.swing.JCheckBox;
import javax.swing.JFormattedTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import BaseDeDatos.BaseDeDatos;
import clases.Administrador;

import java.awt.SystemColor;
import java.awt.Color;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JSeparator;
import javax.swing.JComboBox;

public class VentanaInicioSesion extends JFrame {

	private JFrame frmVentanaInicioSesin;
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton btnNewButton_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaInicioSesion window = new VentanaInicioSesion();
					window.frmVentanaInicioSesin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaInicioSesion() {
		BaseDeDatos.inicioConexion("BaseDeDatos1.db");
		initialize();
		
		
		
		
	}
	
	


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVentanaInicioSesin = new JFrame();
		frmVentanaInicioSesin.getContentPane().setBackground(new Color(0xa8ccba));
		frmVentanaInicioSesin.setTitle("Inicio sesion");
		frmVentanaInicioSesin.setBounds(200, 200, 500, 300);
		frmVentanaInicioSesin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmVentanaInicioSesin.getContentPane().setLayout(null);
		

		JLabel lblNewLabel = new JLabel("Deustock ®");
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Raleway SemiBold", Font.ITALIC, 20));
		lblNewLabel.setBounds(29, 24, 119, 25);
		frmVentanaInicioSesin.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Usuario");
		lblNewLabel_1.setBounds(29, 103, 45, 13);
		frmVentanaInicioSesin.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Contraseña");
		lblNewLabel_2.setBounds(29, 149, 79, 13);
		frmVentanaInicioSesin.getContentPane().add(lblNewLabel_2);

		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setBounds(105, 100, 119, 19);
		frmVentanaInicioSesin.getContentPane().add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(105, 146, 119, 19);
		frmVentanaInicioSesin.getContentPane().add(passwordField);

		btnNewButton_2 = new JButton("Entrar");
		btnNewButton_2.setBackground(SystemColor.desktop);
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setBounds(105, 198, 119, 32);
		
		btnNewButton_2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				chequearInicioSesion();
				

			}
		});

		frmVentanaInicioSesin.getContentPane().add(btnNewButton_2);

		lblNewLabel_3 = new JLabel("¿Nuevo en Deustock? \r\n");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(282, 93, 151, 32);
		frmVentanaInicioSesin.getContentPane().add(lblNewLabel_3);

		lblNewLabel_4 = new JLabel("Reg\u00EDstrate ahora");
		lblNewLabel_4.setBounds(294, 114, 109, 32);
		frmVentanaInicioSesin.getContentPane().add(lblNewLabel_4);

		btnNewButton = new JButton("Crear cuenta");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(SystemColor.desktop);
		btnNewButton.setBounds(294, 156, 124, 32);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				new VR();
			}
		});
		
		
		
		

		frmVentanaInicioSesin.getContentPane().add(btnNewButton);
		
		

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 70, 466, 34);
		frmVentanaInicioSesin.getContentPane().add(separator);
		frmVentanaInicioSesin.setVisible(true);

	}
	
	private void chequearInicioSesion() {
		ArrayList<String> listaAdministradores = BaseDeDatos.getAdministradores();
		ArrayList<String> listaUsuarios = BaseDeDatos.getClientes();
		System.out.println(listaAdministradores);
		String usuario = textField.getText();
		
		if(usuario.equals("") || passwordField.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Rellena todos los campos"); // Si alguno de los campos esta vacio
		}else {
			if(listaAdministradores.contains(usuario)) {
				System.out.println("Existe este usuario");
				String contrase�a = BaseDeDatos.getContrase�aAdministrador(textField.getText());
				System.out.println(contrase�a);
			
				if(passwordField.getText().equals(contrase�a)) {
					VentanaMain ventana = new VentanaMain();
					ventana.setVisible(true);
				}else {
					JOptionPane.showMessageDialog(null, "Contrase�a incorrecta");
				}
			
			}else if(listaUsuarios.contains(usuario)){
				System.out.println("Eres un cliente");
				String contrase�a2 = BaseDeDatos.getContrase�aCliente(textField.getText());
				System.out.println(contrase�a2);
			
				if(passwordField.getText().equals(contrase�a2)) {
					BaseDeDatos.almacenarClienteVentana(usuario);
					VentanaUsuario ventana = new VentanaUsuario();
					ventana.setVisible(true);
					
				}else {
					JOptionPane.showMessageDialog(null, "Contrase�a incorrecta");
				}
			
			}else {
				JOptionPane.showMessageDialog(null, "Primero debes registrarte");
			}
		}
	}
	
	
	
}
