package ventanas;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import enumeraciones.MarcasProductos;
import enumeraciones.TallaParteArribaYAbajo;
import enumeraciones.TipoPantalon;
import enumeraciones.TipoZapatilla;
import BaseDeDatos.BaseDeDatos;
import clases.AtuendoZapatilla;
import clases.AtuendosParteAbajo;
import clases.AtuendosParteArriba;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class VentanaZapatillas extends JFrame {
	private JLabel logo; // }<-- Panel Superior
	private JPanel superiorLogo;
	private JButton btnInicio;
	private JLabel labelOrdenar;
	private JComboBox comboOrdenar;
	private JPanel superiorVentanas;
	private JButton btnCarrito;
	private JLabel totalLbl;
	private JPanel superiorCarrito;
	private JPanel superior;
	private JPanel core; // centro
	private JPanel panelPago;
	private JPanel margenIzq; // }<-- Margen
	private JButton btnCrearProducto;
	private JButton btnBorrarProducto;
	private DefaultTableModel mDatos; // Modelo de datos de tabla central
	private JTable tDatos;
	private JTree arbolAtuendo; // ARBOL DE TIPO DE ATUENDO
	private DefaultTreeModel modeloArbol; // MODELO DEL ARBOL
	private int tipo;

	public VentanaZapatillas() {
		this.setTitle("Pago");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setLayout(new BorderLayout());

// Panel Superior

		// Panel Superior Izquierda

		logo = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/logo.png"));
			logo.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		logo.setBounds(0, 0, 200, 95);

		superiorLogo = new JPanel();
		superiorLogo.setPreferredSize(new Dimension(169, 96));
		superiorLogo.setBackground(Color.WHITE);
		superiorLogo.setLayout(null);
		superiorLogo.add(logo);

		// Panel Superior Centro
		// TODO setLayout(new GridBagLayout()); <-- La idea es que los botones se
		// adapten al tama�o

		btnInicio = new JButton("INICIO");
		btnInicio.setBounds(20, 35, 160, 35);
		btnInicio.setFont(new Font("Roboto", Font.BOLD, 25));
		btnInicio.setForeground(new Color(0xa8ccba));
		btnInicio.setBackground(Color.WHITE);
		btnInicio.setBorderPainted(false);

		labelOrdenar = new JLabel("Ordenar por:");
		labelOrdenar.setBounds(230, 35, 190, 35);
		labelOrdenar.setFont(new Font("Consolas", Font.BOLD, 25));
		labelOrdenar.setForeground(new Color(0xa8ccba));
		labelOrdenar.setBackground(Color.WHITE);

		
		comboOrdenar = new JComboBox(new Object[] {"No ordenar", "id", "marca", "precio"});
		comboOrdenar.setBounds(440, 35, 160, 35);
		comboOrdenar.setFont(new Font("Roboto", Font.BOLD, 25));
		comboOrdenar.setForeground(new Color(0xa8ccba));
		comboOrdenar.setBackground(Color.WHITE);

		/*btnCuenta = new JButton();
		try {
			Image img = ImageIO.read(getClass().getResource("/cuenta.png"));
			btnCuenta.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		btnCuenta.setText("CUENTA: ");
		btnCuenta.setIconTextGap(10);
		btnCuenta.setBounds(640, 5, 250, 90);
		btnCuenta.setFont(new Font("Roboto", Font.BOLD, 24));
		btnCuenta.setForeground(new Color(0xa8ccba));
		btnCuenta.setBackground(Color.WHITE);
		btnCuenta.setBorderPainted(false);
		btnCuenta.setHorizontalTextPosition(JButton.LEFT);
		btnCuenta.setVerticalTextPosition(JButton.CENTER);*/

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0xa2d39b));
		separator.setBounds(0, 95, 2000, 7);

		superiorVentanas = new JPanel();
		superiorVentanas.setBackground(Color.WHITE);
		superiorVentanas.setPreferredSize(new Dimension(0, 0));
		superiorVentanas.setLayout(null);
		superiorVentanas.add(btnInicio);
		superiorVentanas.add(labelOrdenar);
		superiorVentanas.add(comboOrdenar);

		superiorVentanas.add(separator);

		// Panel Superior Derecha

		totalLbl = new JLabel();
		totalLbl.setText("  Total:");
		totalLbl.setForeground(Color.WHITE);
		totalLbl.setFont(new Font("Consolas", Font.BOLD, 20));
		totalLbl.setPreferredSize(new Dimension(100, 50));

		btnCarrito = new JButton();
		try {
			Image img = ImageIO.read(getClass().getResource("/carrito.png"));
			btnCarrito.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		btnCarrito.setPreferredSize(new Dimension(100, 100));
		btnCarrito.setBackground(new Color(0xa8ccba));
		btnCarrito.setForeground(new Color(0xa8ccba));
		btnCarrito.setBorderPainted(false);

		superiorCarrito = new JPanel();
		superiorCarrito.setBackground(new Color(0xa8ccba));
		superiorCarrito.setPreferredSize(new Dimension(200, 0));
		superiorCarrito.setLayout(new BorderLayout());
		superiorCarrito.add(totalLbl, BorderLayout.EAST);
		superiorCarrito.add(btnCarrito, BorderLayout.WEST);

		// Build

		superior = new JPanel();
		superior.setBackground(Color.WHITE);
		superior.setPreferredSize(new Dimension(0, 100));
		superior.setLayout(new BorderLayout());
		superior.add(superiorLogo, BorderLayout.WEST);
		superior.add(superiorVentanas, BorderLayout.CENTER);
		superior.add(superiorCarrito, BorderLayout.EAST);

// Panel Central

		// Panel Inicio

		// Panel

		// Panel Pago

		
		
		
		tDatos = new JTable();
		tDatos.setFont(new Font("Arial", Font.PLAIN, 14));

		
		
// Margen Izquierdo

		btnCrearProducto = new JButton("Crear Producto");
		//btnCrearProducto.setBounds(0, 30, 180, 20);
		btnCrearProducto.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnCrearProducto.setForeground(new Color(0xffffff));
		btnCrearProducto.setBackground(new Color(0xa8ccba));
		btnCrearProducto.setBorderPainted(false);

		btnBorrarProducto = new JButton("Borrar Producto");
		//btnBorrarProducto.setBounds(10, 65, 175, 20);
		btnBorrarProducto.setFont(new Font("Roboto", Font.PLAIN, 20));
		btnBorrarProducto.setForeground(new Color(0xffffff));
		btnBorrarProducto.setBackground(new Color(0xa8ccba));
		btnBorrarProducto.setBorderPainted(false);

		
		
		arbolAtuendo = new JTree();
		arbolAtuendo.setFont(new Font("Roboto", Font.PLAIN, 20));
		arbolAtuendo.setForeground(new Color(0xffffff));
		arbolAtuendo.setBackground(new Color(0xa8ccba));
		cargarArbol();


		margenIzq = new JPanel();
		margenIzq.setBackground(new Color(0xa8ccba));
		margenIzq.setPreferredSize(new Dimension(170, 0));
		//margenIzq.setLayout(null);
		margenIzq.add(new JScrollPane(arbolAtuendo));
		margenIzq.add(btnCrearProducto);
		margenIzq.add(btnBorrarProducto);
		

		this.add(superior, BorderLayout.NORTH);
		this.add(margenIzq, BorderLayout.WEST);
		this.add(new JScrollPane(tDatos), BorderLayout.CENTER);

		addWindowListener(new WindowAdapter() {

			public void windowOpened(WindowEvent e) {
				BaseDeDatos.inicioConexion("BaseDeDatos1.db");
				verProductos();
				
			}

			public void windowClosed(WindowEvent e) {
				BaseDeDatos.cerrarConexion();
			}

		});
		
		
		btnInicio.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaMain ventana = new VentanaMain();
				ventana.setVisible(true);
				
			}
			
		});
		

		btnCrearProducto.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CrearProducto();
				

			}

		});

		btnBorrarProducto.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				EliminarProducto();

			}

		});

		
		
		arbolAtuendo.addTreeSelectionListener(new TreeSelectionListener() {

			@Override
			public void valueChanged(TreeSelectionEvent e) {
				// TODO Auto-generated method stub
				TreePath tp = e.getPath();
				Object[] ruta = tp.getPath();
				String tipoAtuendo = ruta[ruta.length-1].toString();
				System.out.println(tipoAtuendo);
				
				if(tipoAtuendo.equals("Atuendos")){
					verProductos();
					tipo = 0;
					
				}else if(tipoAtuendo.equals("DEPORTE")){
					verProductos(tipoAtuendo);
					tipo = 1;
					
					
				}else if(tipoAtuendo.equals("STREETSPORT")) {
					verProductos(tipoAtuendo);
					tipo = 2;
					
				}else if(tipoAtuendo.equals("BOTAS")) {
					verProductos(tipoAtuendo);
					tipo = 3;
					
				}else if(tipoAtuendo.equals("TACONES")){
					verProductos(tipoAtuendo);
					tipo = 4;
					
				}else {
					verProductos(tipoAtuendo);
					tipo = 5;
				}
				
				
			}
			
		});
		
		
		comboOrdenar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String elegido = comboOrdenar.getSelectedItem().toString();
				if(elegido.equals("No ordenar")) {
									
					if(tipo==0) {
						verProductos();
					}else if(tipo == 1) {
						verProductos("DEPORTE");
					}else if(tipo == 2) {
						verProductos("STREETSPORT");
					}else if(tipo == 3) {
						verProductos("BOTAS");
					}else if(tipo == 4){
						verProductos("TACONES");
					}else {
						verProductos("BAILARINAS");
					}
					
					
				}else {
					
					if(tipo==0) {
						verProductosOrdenados(elegido);
					}else if(tipo == 1) {
						verProductosOrdenadosPorTipo(elegido, "DEPORTE");
					}else if(tipo == 2) {
						verProductosOrdenadosPorTipo(elegido, "STREETSPORT");
					}else if(tipo == 3) {
						verProductosOrdenadosPorTipo(elegido, "BOTAS");
					}else if(tipo == 4){
						verProductosOrdenadosPorTipo(elegido, "TACONES");
					}else {
						verProductosOrdenadosPorTipo(elegido, "BAILARINAS");
					}
				}
			}
			
		});
		
		
		

	}
		
		
	
	
	
	
	private void verProductos() {
		ModeloTabla(BaseDeDatos.getZapatillas());
		
	}
	

	private void verProductos(String tipo) {
		ModeloTabla(BaseDeDatos.getZapatillasPorTipo(tipo));
		
	}
	
	private void verProductosOrdenados(String categoria) {
		ModeloTabla(BaseDeDatos.getZapatillasOrdenado(categoria));
		
	}
	
	private void verProductosOrdenadosPorTipo(String categoria, String tipo) {
		ModeloTabla(BaseDeDatos.getZapatillasPorTipoYOrdenados(categoria, tipo));
		
	}
	
	
	
	
	
	private void ModeloTabla(ArrayList<AtuendoZapatilla> lista) {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "Genero", "Peso", "Color",
				"Material", "Estampado", "Cantidad", "Talla", "Color Cordon", "Tipo"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		) {
			public boolean isCellEditable(int row, int column) {
				if(column==1 || column==2 || column==3 || column==4 || column==5 || column==6 || column==7 || column==8 || column==9 || column==10 || column ==11 || column ==12)
					return true;
				else {
					return false;
				}
			}
		};
		
		ArrayList<AtuendoZapatilla> productosZapatilla = lista;
	
		for (AtuendoZapatilla producto : productosZapatilla) {
			mDatos.addRow(new Object[] { producto.getId(), producto.getNombre(), producto.getPrecio(),
					producto.getMarca(), producto.getGenero(), producto.getPeso(), producto.getColor(), producto.getMaterial(),
					producto.getEstampado(), producto.getCantidad(), producto.getTalla(), producto.getColorCordon(), producto.getTipo()});
		}

		tDatos.setModel(mDatos);
		
		
		tDatos.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				// TODO Auto-generated method stub
				int fila = e.getFirstRow();
				int id = (int) mDatos.getValueAt(fila, 0);
				String nombre = (String) mDatos.getValueAt(fila, 1);
				int precio = (int) mDatos.getValueAt(fila, 2);
				MarcasProductos marca = (MarcasProductos) mDatos.getValueAt(fila, 3);
				String genero = (String) mDatos.getValueAt(fila, 4);
				int peso = (int) mDatos.getValueAt(fila, 5);
				String color = (String) mDatos.getValueAt(fila, 6);
				String material = (String) mDatos.getValueAt(fila, 7);
				Boolean estampado = (Boolean) mDatos.getValueAt(fila, 8);
				int cantidad = (int) mDatos.getValueAt(fila, 9);
				String talla = (String) mDatos.getValueAt(fila, 10);
				String colorCordon = (String) mDatos.getValueAt(fila, 11);
				TipoZapatilla tipoProducto = (TipoZapatilla) mDatos.getValueAt(fila, 12);
				BaseDeDatos.modificarZapatillas(new AtuendoZapatilla(id, nombre, precio, marca, genero, peso, color, material, estampado, cantidad, talla, colorCordon, tipoProducto));
				
			}
			
		});
		
	}
	
	
	
	
	private void CrearProducto() {
		String nombre = JOptionPane.showInputDialog("Introduce el nombre del producto");
		int precio = Integer.parseInt(JOptionPane.showInputDialog("Introduce el precio del producto"));
		MarcasProductos marca = selMarca();
		String genero = selGenero();
		int peso = Integer.parseInt(JOptionPane.showInputDialog("Introduce el peso del producto"));
		String color = selColor();
		String material = JOptionPane.showInputDialog("Introduce el material del producto");
		Boolean estampado = selEstampado();
		int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Introduce cantidad del producto"));
		String talla = selTalla();
		String colorCordon = selColor();
		TipoZapatilla tipo = selTipo();
		BaseDeDatos.crearAtuendoZapatilla(new AtuendoZapatilla(1, nombre, precio, marca, genero, peso, color, material, estampado, cantidad, talla, colorCordon, tipo));
		
		verProductos();
	}
	
	
	private void EliminarProducto() {
		int filaSeleccionada = tDatos.getSelectedRow();
		if(filaSeleccionada != -1) {
			int id = (int) mDatos.getValueAt(filaSeleccionada, 0);
			BaseDeDatos.BorrarProductoZapatilla(id);
			mDatos.removeRow(filaSeleccionada);
			
		}else {
			JOptionPane.showMessageDialog(null, "No has seleccionado ningun producto para borrar");
		}
		
	};
	
	
	private String selColor() {
		Object selColor = JOptionPane.showInputDialog(null, "Selecciona un color: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Negro", "Azul", "Blanco", "Rojo", "Gris", "Verde", "Amarillo"} , null);
		if (selColor==null) {
			return null;
		}
		String colorElegido = (String) selColor;
		return colorElegido;
		
	}
	
	private String selGenero() {
		Object selGenero = JOptionPane.showInputDialog(null, "Selecciona el genero: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Hombre", "Mujer", "Unisex"} , null);
		if (selGenero==null) {
			return null;
		}
		String generoElegido = (String) selGenero;
		return generoElegido;
		
	}
	
	
	private Boolean selEstampado() {
		Boolean estampadoElegido = true;
		Object selEstampado = JOptionPane.showInputDialog(null, "Quieres que tenga estampado: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Si", "No"} , null);
		String elegido = (String) selEstampado;
		if (elegido==null) {
			return null;
		}
		if(elegido.equals("Si")){
			estampadoElegido = true;
			return estampadoElegido;
		}else if(elegido.equals("No")){
			estampadoElegido = false;
			return estampadoElegido;
		}
		return estampadoElegido;
		
	}
	
	
	private String selTalla() {
		Object selTalla = JOptionPane.showInputDialog(null, "Selecciona una talla: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, new Object[] {"36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48"} , null);
		if (selTalla==null) {
			return null;
		}
		String tallaElegida = (String) selTalla;
		return tallaElegida;
		
	}
	
	
	private MarcasProductos selMarca(){
		MarcasProductos[] marcas = new MarcasProductos[ 20 ];
		int i = 0;
		for(MarcasProductos marca : MarcasProductos.values()) {
			marcas[ i ] = marca;	
			i++;
		}
		Object selMarca = JOptionPane.showInputDialog(null, "Elige la marca: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, marcas , null);
		return (MarcasProductos) selMarca;
	}
	
	
	private TipoZapatilla selTipo(){
		TipoZapatilla[] tipos = new TipoZapatilla[ 5 ];
		int i = 0;
		for(TipoZapatilla tipo : TipoZapatilla.values()) {
			tipos[ i ] = tipo;	
			i++;
		}
		Object selTipo = JOptionPane.showInputDialog(null, "Elige el tipo de zapatilla: ", "A�adir producto", JOptionPane.QUESTION_MESSAGE, null, tipos , null);
		return (TipoZapatilla) selTipo;
	}
	
	
	
private void cargarArbol() {
		
		DefaultMutableTreeNode raiz = new DefaultMutableTreeNode("Atuendos");
		modeloArbol = new DefaultTreeModel(raiz);
		
		DefaultMutableTreeNode hijo1 = new DefaultMutableTreeNode("DEPORTE");
		DefaultMutableTreeNode hijo2 = new DefaultMutableTreeNode("STREETSPORT");
		DefaultMutableTreeNode hijo3 = new DefaultMutableTreeNode("BOTAS");
		DefaultMutableTreeNode hijo4 = new DefaultMutableTreeNode("TACONES");
		DefaultMutableTreeNode hijo5 = new DefaultMutableTreeNode("BAILARINAS");
			
		modeloArbol.insertNodeInto(hijo1, raiz, 0);
		modeloArbol.insertNodeInto(hijo2, raiz, 1);
		modeloArbol.insertNodeInto(hijo3, raiz, 2);
		modeloArbol.insertNodeInto(hijo4, raiz, 3);
		modeloArbol.insertNodeInto(hijo5, raiz, 3);
			
		arbolAtuendo.setModel(modeloArbol);
		
		
	}
	
	
	
	
	
	
}
