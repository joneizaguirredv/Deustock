package ventanas;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


import BaseDeDatos.BaseDeDatos;
import clases.AtuendosParteArriba;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Vector;

public class VentanaMain extends JFrame {
	private JLabel logo; // }<-- Panel Superior
	private JPanel superiorLogo;
	private JButton btnInicio;
	private JPanel superiorVentanas;
	private JButton btnCarrito;
	private JLabel totalLbl;
	private JPanel superiorCarrito;
	private JPanel superior;
	private JPanel core; // centro
	private JPanel panelPago;
	private JPanel margenIzq; // }<-- Margen
	private JButton btnParteArriba;
	private JButton btnParteAbajo;
	private JButton btnCalzado;
	private DefaultTableModel mDatos; // Modelo de datos de tabla central
	private JTable tDatos;

	public VentanaMain() {
		this.setTitle("Pago");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setLayout(new BorderLayout());

// Panel Superior

		// Panel Superior Izquierda

		logo = new JLabel();
		try {
			Image img = ImageIO.read(getClass().getResource("/logo.png"));
			logo.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		logo.setBounds(0, 0, 200, 95);

		superiorLogo = new JPanel();
		superiorLogo.setPreferredSize(new Dimension(169, 96));
		superiorLogo.setBackground(Color.WHITE);
		superiorLogo.setLayout(null);
		superiorLogo.add(logo);

		// Panel Superior Centro
		// TODO setLayout(new GridBagLayout()); <-- La idea es que los botones se
		// adapten al tama�o

		btnInicio = new JButton("INICIO");
		btnInicio.setBounds(20, 35, 160, 35);
		btnInicio.setFont(new Font("Roboto", Font.BOLD, 25));
		btnInicio.setForeground(new Color(0xa8ccba));
		btnInicio.setBackground(Color.WHITE);
		btnInicio.setBorderPainted(false);

		

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0xa2d39b));
		separator.setBounds(0, 95, 2000, 7);

		superiorVentanas = new JPanel();
		superiorVentanas.setBackground(Color.WHITE);
		superiorVentanas.setPreferredSize(new Dimension(0, 0));
		superiorVentanas.setLayout(null);
		superiorVentanas.add(btnInicio);
		superiorVentanas.add(separator);

		// Panel Superior Derecha

		totalLbl = new JLabel();
		totalLbl.setText("  Total:");
		totalLbl.setForeground(Color.WHITE);
		totalLbl.setFont(new Font("Consolas", Font.BOLD, 20));
		totalLbl.setPreferredSize(new Dimension(100, 50));

		btnCarrito = new JButton();
		try {
			Image img = ImageIO.read(getClass().getResource("/carrito.png"));
			btnCarrito.setIcon(new ImageIcon(img));
		} catch (Exception ex) {
			System.out.println(ex);
		}
		btnCarrito.setPreferredSize(new Dimension(100, 100));
		btnCarrito.setBackground(new Color(0xa8ccba));
		btnCarrito.setForeground(new Color(0xa8ccba));
		btnCarrito.setBorderPainted(false);

		superiorCarrito = new JPanel();
		superiorCarrito.setBackground(new Color(0xa8ccba));
		superiorCarrito.setPreferredSize(new Dimension(200, 0));
		superiorCarrito.setLayout(new BorderLayout());
		superiorCarrito.add(totalLbl, BorderLayout.EAST);
		superiorCarrito.add(btnCarrito, BorderLayout.WEST);

		// Build

		superior = new JPanel();
		superior.setBackground(Color.WHITE);
		superior.setPreferredSize(new Dimension(0, 100));
		superior.setLayout(new BorderLayout());
		superior.add(superiorLogo, BorderLayout.WEST);
		superior.add(superiorVentanas, BorderLayout.CENTER);
		superior.add(superiorCarrito, BorderLayout.EAST);

// Panel Central

		// Panel Inicio

		// Panel

		// Panel Pago

		tDatos = new JTable();
		tDatos.setFont(new Font("Arial", Font.PLAIN, 14));

// Margen Izquierdo

		btnParteArriba = new JButton("Atuendo Superior");
		btnParteArriba.setBounds(0, 30, 180, 20);
		btnParteArriba.setFont(new Font("Roboto", Font.PLAIN, 18));
		btnParteArriba.setForeground(new Color(0xffffff));
		btnParteArriba.setBackground(new Color(0xa8ccba));
		btnParteArriba.setBorderPainted(false);

		btnParteAbajo = new JButton("Atuendo Inferior");
		btnParteAbajo.setBounds(10, 65, 175, 20);
		btnParteAbajo.setFont(new Font("Roboto", Font.PLAIN, 20));
		btnParteAbajo.setForeground(new Color(0xffffff));
		btnParteAbajo.setBackground(new Color(0xa8ccba));
		btnParteAbajo.setBorderPainted(false);

		btnCalzado = new JButton("Calzado");
		btnCalzado.setBounds(10, 90, 175, 50);
		btnCalzado.setFont(new Font("Roboto", Font.PLAIN, 20));
		btnCalzado.setForeground(new Color(0xffffff));
		btnCalzado.setBackground(new Color(0xa8ccba));
		btnCalzado.setBorderPainted(false);

		margenIzq = new JPanel();
		margenIzq.setBackground(new Color(0xa8ccba));
		margenIzq.setPreferredSize(new Dimension(170, 0));
		margenIzq.setLayout(null);
		margenIzq.add(btnParteArriba);
		margenIzq.add(btnParteAbajo);
		margenIzq.add(btnCalzado);

		this.add(superior, BorderLayout.NORTH);
		this.add(margenIzq, BorderLayout.WEST);
		this.add(new JScrollPane(tDatos), BorderLayout.CENTER);

		addWindowListener(new WindowAdapter() {

			public void windowOpened(WindowEvent e) {
				
			}

			public void windowClosed(WindowEvent e) {
				
			}

		});
		
		
		

		btnParteArriba.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaAtuendosParteArriba ventana = new VentanaAtuendosParteArriba();
				ventana.setVisible(true);

			}

		});

		btnParteAbajo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaAtuendosParteAbajo ventana = new VentanaAtuendosParteAbajo();
				ventana.setVisible(true);

			}

		});

		btnCalzado.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaZapatillas ventana = new VentanaZapatillas();
				ventana.setVisible(true);

			}

		});

	}

	private void verProductosParteArriba() {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "Peso", "Color",
				"Material", "Estampado", "Cantidad", "Talla"));
		mDatos = new DefaultTableModel( // Inicializa el modelo
				new Vector<Vector<Object>>(), // Datos de la jtable (vector de vectores)
				cabeceras // Cabeceras de la jtable
		);

		ArrayList<AtuendosParteArriba> productosParteArriba = BaseDeDatos.getAtuendosParteArriba();

		/*for (AtuendosParteArriba producto : productosParteArriba) {
			System.out.println(producto);
			mDatos.addRow(new Object[] { producto.getId(), producto.getNombre(), producto.getPrecio(),
					producto.getMarca(), producto.getPeso(), producto.getColor(), producto.getMaterial(),
					producto.getEstampado(), producto.getCantidad(), producto.getTallaArriba() });
		}*/

		tDatos.setModel(mDatos);
	}

	private void verProductosParteAbajo() {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "Peso", "Color",
				"Material", "Estampado", "Cantidad", "Tipo", "Talla"));
		mDatos = new DefaultTableModel(new Vector<Vector<Object>>(), cabeceras);
		tDatos.setModel(mDatos);
	}

	private void verProductosCalzado() {
		Vector<String> cabeceras = new Vector<String>(Arrays.asList("Id", "Nombre", "Precio", "Marca", "Peso", "Color",
				"Material", "Estampado", "Talla", "Color", "Tipo"));
		mDatos = new DefaultTableModel(new Vector<Vector<Object>>(), cabeceras);
		tDatos.setModel(mDatos);
	}

	public static void main(String[] args) {
		VentanaMain ventana = new VentanaMain();
		ventana.setVisible(true);
	}
}
