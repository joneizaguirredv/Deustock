package ventanas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaCoockies extends JFrame {
	private JTextField Politica;
	private JLabel TextoSuperior;
	private JLabel TextoCentral;
	private JLabel TextoCentral2;
	private JLabel TextoCentral3;
	private JLabel TextoCentral4;
	private JButton btnAceptar;
	private JButton btnRechazar;
	private JPanel pNorte;
	private JPanel pSur;
	private JPanel pCentro;

	public VentanaCoockies() {
		this.setTitle("Coockies");
		this.setSize(700, 200);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setResizable(false);
		this.setLocationRelativeTo(null);

		btnAceptar = new JButton("Aceptar");
		btnRechazar = new JButton("Rechazar");
		TextoSuperior = new JLabel("Terminos y condiciones de la pagina web");
		TextoCentral = new JLabel(
				"Utilizaremos coockies propias y de terceros para mejorar nuestros servicios y mostrarte publicidad relacionada.");
		TextoCentral2 = new JLabel("con tus preferencias, mediante el analis de tus habitos de navegacion.");
		TextoCentral3 = new JLabel(
				"Pulsa el boton ACEPTAR para conmfirmar que has leido y aceptado la informacion presentada.");
		TextoCentral4 = new JLabel("Despues de aceptar, no volveremos a mostrarte este mensaje.");

		pSur = new JPanel(new FlowLayout());
		pCentro = new JPanel(new FlowLayout());
		pNorte = new JPanel(new FlowLayout());

		pSur.add(btnAceptar);
		pSur.add(btnRechazar);
		pNorte.add(TextoSuperior);
		pCentro.add(TextoCentral);
		pCentro.add(TextoCentral2);
		pCentro.add(TextoCentral3);
		pCentro.add(TextoCentral4);

		this.add(pSur, BorderLayout.SOUTH);
		this.add(pNorte, BorderLayout.NORTH);
		this.add(pCentro, BorderLayout.CENTER);

		btnRechazar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaAviso ventana = new VentanaAviso();
				ventana.setVisible(true);

			}

		});

		btnAceptar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				VentanaInicioSesion ventana = new VentanaInicioSesion();
				ventana.setVisible(true);

			}

		});

	}

	public static void main(String[] args) {
		VentanaCoockies ventana = new VentanaCoockies();
		ventana.setVisible(true);
	}

}
