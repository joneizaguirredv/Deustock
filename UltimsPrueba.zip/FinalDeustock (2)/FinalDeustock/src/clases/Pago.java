package clases;

import excepciones.MiExcepcionExplicita;

public class Pago extends Usuario{
	
	private String CuentaBancaria;
	private String Caducidad;
	private String Cvv;
	
	public Pago(int id, String correo, String nombre, String apellido, String contrase�a, String cuentaBancaria, String caducidad, String cvv)
			throws MiExcepcionExplicita {
		super(id, correo, contrase�a, nombre, apellido);
		CuentaBancaria = cuentaBancaria;
		Caducidad = caducidad;
		Cvv = cvv;
		
	}
	
	public String getCuentaBancaria() {
		return CuentaBancaria;
	}
	
	public void setCuentaBancaria(String cuentaBancaria) {
		CuentaBancaria = cuentaBancaria;
	}
	
	public String getCaducidad() {
		return Caducidad;
	}
	
	public void setCaducidad(String caducidad) {
		Caducidad = caducidad;
	}
	
	public String getCvv() {
		return Cvv;
	}
	
	public void setCvv(String cvv) {
		Cvv = cvv;
	}
	
	public String toString() {
		return "Pago [CuentaBancaria=" + CuentaBancaria + ", Caducidad=" + Caducidad + ", Cvv=" + Cvv +", toString()=" + super.toString() + "]";
	}

}
