package clases;

import excepciones.MiExcepcionExplicita;

public class Cliente extends Usuario {
	private int Telefono;
	private int CodigoPostal;


	public Cliente(int id, String correo, String nombre, String apellido, String contrase�a, int telefono, int codigoPostal)
			throws MiExcepcionExplicita {
		super(id, correo, contrase�a, nombre, apellido);
		Telefono = telefono;
		CodigoPostal = codigoPostal;
	}

	public int getTelefono() {
		return Telefono;
	}

	public void setTelefono(int telefono) {
		Telefono = telefono;
	}

	public int getCodigoPostal() {
		return CodigoPostal;
	}

	public void setCodigoPostal(int codigoPostal) {
		CodigoPostal = codigoPostal;
	}



	@Override
	public String toString() {
		return "Cliente [Telefono=" + Telefono + ", CodigoPostal=" + CodigoPostal + ", toString()=" + super.toString() + "]";
	}

}