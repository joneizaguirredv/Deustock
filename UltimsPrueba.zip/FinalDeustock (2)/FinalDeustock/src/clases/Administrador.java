package clases;

import excepciones.MiExcepcionExplicita;

public class Administrador extends Usuario {

	private String NSS;

	public Administrador(int id, String correo, String contrase�a, String nombre, String apellido, String nSS) throws MiExcepcionExplicita {
		super(id, correo, contrase�a, nombre, apellido);
		NSS = nSS;
	}

	public String getNSS() {
		return NSS;
	}

	public void setNSS(String nSS) {
		NSS = nSS;
	}

	

	@Override
	public String toString() {
		return "Administrador [NSS=" + NSS + "]";
	}

	@Override
	public boolean puedeEditar() {
		return true;
	}

}